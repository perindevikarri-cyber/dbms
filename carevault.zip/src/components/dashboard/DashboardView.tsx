import React, { useState } from 'react';
import {
  Users,
  UserCheck,
  Calendar,
  AlertCircle,
  TrendingUp,
  Search,
  ArrowRight,
  FlaskConical,
  Receipt,
  Sparkles,
  ChevronRight,
  Clock,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { dbOverviewService } from '../../services/dbOverviewService';
import { patientService } from '../../services/patientService';
import { appointmentService } from '../../services/appointmentService';
import { laboratoryService } from '../../services/laboratoryService';
import { billingService } from '../../services/billingService';
import { Badge } from '../common/Badge';
import { ConceptBanner } from '../common/ConceptBanner';

interface DashboardViewProps {
  onSelectPatient: (patientId: number) => void;
  onNavigateTab: (tab: any) => void;
  onOpenSchema: () => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onSelectPatient,
  onNavigateTab,
  onOpenSchema,
  onNotify,
}) => {
  const [quickSearch, setQuickSearch] = useState('');
  const stats = dbOverviewService.getStats();

  const recentPatients = patientService.getAll().slice(0, 5);
  const appointmentsJoined = appointmentService.getAllJoined().slice(0, 5);
  const recentLabs = laboratoryService.getAllJoined().slice(0, 4);
  const pendingBills = billingService.getAllJoined().filter((b) => b.Payment_Status === 'Pending').slice(0, 4);

  const handleQuickSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickSearch.trim()) return;
    const results = patientService.search(quickSearch);
    if (results.length > 0) {
      onSelectPatient(results[0].Patient_ID);
    } else {
      onNotify('error', `No patient record found matching "${quickSearch}". Try "Rahul Kumar" or "1".`);
    }
  };

  const handlePayPendingBill = (billId: number) => {
    billingService.updateStatus(billId, 'Paid');
    onNotify('success', `Bill #${billId} paid successfully.`);
  };

  return (
    <div className="space-y-6">
      {/* Header with Title and Subtitle */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            Hospital Records Overview
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-sky-50 text-sky-800 border border-sky-200">
              DBMS Live Session
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Centralized digital management of hospital information.
          </p>
        </div>

        {/* Quick Demo Button for Rahul Kumar */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onSelectPatient(1)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-600 to-sky-600 hover:from-teal-700 hover:to-sky-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-500/10 transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-teal-200" />
            <span>Demonstrate: Rahul Kumar (ID #1)</span>
          </button>
        </div>
      </div>

      {/* Visual Project Story Concept Banner */}
      <ConceptBanner onQuickDemo={() => onSelectPatient(1)} />

      {/* 4 Main Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Patients */}
        <div
          onClick={() => onNavigateTab('patients')}
          className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:border-teal-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 group-hover:text-teal-700">
              Total Patients
            </span>
            <div className="p-2.5 rounded-xl bg-teal-50 text-teal-700 group-hover:bg-teal-600 group-hover:text-white transition-colors">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{stats.totalPatients}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
            <span>MySQL Table: <code className="font-mono text-slate-700">Patient</code></span>
            <span className="text-teal-700 font-bold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
              View <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Total Doctors */}
        <div
          onClick={() => onNavigateTab('doctors')}
          className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:border-sky-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 group-hover:text-sky-700">
              Total Doctors
            </span>
            <div className="p-2.5 rounded-xl bg-sky-50 text-sky-700 group-hover:bg-sky-600 group-hover:text-white transition-colors">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{stats.totalDoctors}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
            <span>5 Specialized Depts</span>
            <span className="text-sky-700 font-bold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
              View <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Today's Appointments */}
        <div
          onClick={() => onNavigateTab('appointments')}
          className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 group-hover:text-indigo-700">
              Scheduled Appts
            </span>
            <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{stats.scheduledAppointmentsCount}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
            <span>{stats.totalAppointments} Total in System</span>
            <span className="text-indigo-700 font-bold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
              Manage <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Pending Bills */}
        <div
          onClick={() => onNavigateTab('billing')}
          className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:border-amber-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 group-hover:text-amber-700">
              Pending Bills
            </span>
            <div className="p-2.5 rounded-xl bg-amber-50 text-amber-700 group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <AlertCircle className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-700 mt-2">
            ₹{stats.pendingBillsAmount.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
            <span>{stats.pendingBillsCount} Invoices Due</span>
            <span className="text-amber-700 font-bold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
              Ledger <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>
      </div>

      {/* Prominent Quick Digital Retrieval Bar on Dashboard */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
              <Search className="w-4 h-4 text-teal-600" />
              Direct Patient Retrieval Console
            </span>
            <p className="text-xs text-slate-500 mt-0.5">
              Enter Patient Name or ID to retrieve all connected files immediately.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Quick Try:</span>
            <button
              onClick={() => onSelectPatient(1)}
              className="px-2.5 py-1 bg-teal-50 text-teal-800 hover:bg-teal-100 font-bold rounded-lg border border-teal-200 cursor-pointer"
            >
              Rahul Kumar (#1)
            </button>
            <button
              onClick={() => onSelectPatient(2)}
              className="px-2.5 py-1 bg-slate-100 text-slate-700 hover:bg-slate-200 font-medium rounded-lg cursor-pointer"
            >
              Priya Sharma (#2)
            </button>
          </div>
        </div>

        <form onSubmit={handleQuickSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={quickSearch}
              onChange={(e) => setQuickSearch(e.target.value)}
              placeholder="Search patient name or ID (e.g. Rahul Kumar, 1)..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 focus:bg-white focus:ring-2 focus:ring-teal-500/20"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-colors shrink-0 cursor-pointer"
          >
            Retrieve File
          </button>
        </form>
      </div>

      {/* Two Column Grid: Recent Patients & Upcoming Appointments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* RECENT PATIENTS */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-teal-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">Recent Patients</h2>
            </div>
            <button
              onClick={() => onNavigateTab('patients')}
              className="text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1 cursor-pointer"
            >
              View All ({stats.totalPatients}) <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-2.5 px-4">Patient ID</th>
                  <th className="py-2.5 px-4">Patient Name</th>
                  <th className="py-2.5 px-4">Age</th>
                  <th className="py-2.5 px-4">Gender</th>
                  <th className="py-2.5 px-4">Blood Group</th>
                  <th className="py-2.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentPatients.map((p) => (
                  <tr
                    key={p.Patient_ID}
                    className={`hover:bg-slate-50 transition-colors ${
                      p.Patient_ID === 1 ? 'bg-teal-50/30' : ''
                    }`}
                  >
                    <td className="py-3 px-4 font-mono font-bold text-slate-700">
                      P{String(p.Patient_ID).padStart(3, '0')}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {p.Name}
                      {p.Patient_ID === 1 && (
                        <span className="ml-1.5 px-1.5 py-0.2 rounded bg-teal-100 text-teal-800 text-[10px] font-bold">
                          Demo
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-medium">{p.Age}</td>
                    <td className="py-3 px-4 text-slate-600">{p.Gender}</td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200 text-[11px]">
                        {p.Blood_Group}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onSelectPatient(p.Patient_ID)}
                        className="px-2.5 py-1 text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-600 hover:text-white rounded-lg border border-teal-200 transition-colors cursor-pointer"
                      >
                        View Record
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* UPCOMING APPOINTMENTS */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">Upcoming Appointments</h2>
            </div>
            <button
              onClick={() => onNavigateTab('appointments')}
              className="text-xs font-bold text-indigo-700 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
            >
              View All ({stats.totalAppointments}) <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-2.5 px-4">Time</th>
                  <th className="py-2.5 px-4">Patient</th>
                  <th className="py-2.5 px-4">Doctor</th>
                  <th className="py-2.5 px-4">Department</th>
                  <th className="py-2.5 px-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {appointmentsJoined.map((appt) => (
                  <tr key={appt.Appointment_ID} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-700">
                      {appt.Appointment_Time}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <button
                        onClick={() => onSelectPatient(appt.Patient_ID)}
                        className="hover:text-teal-700 hover:underline cursor-pointer"
                      >
                        {appt.patient?.Name || `Patient #${appt.Patient_ID}`}
                      </button>
                    </td>
                    <td className="py-3 px-4 text-slate-800 font-medium">
                      {appt.doctor?.Name || `Dr. #${appt.Doctor_ID}`}
                    </td>
                    <td className="py-3 px-4 text-slate-500">{appt.doctor?.Department}</td>
                    <td className="py-3 px-4 text-right">
                      <Badge variant={appt.Status} dot size="sm">
                        {appt.Status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Two Column Grid: Recent Laboratory Reports & Pending Payments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* RECENT LABORATORY REPORTS */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-teal-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">Recent Laboratory Reports</h2>
            </div>
            <button
              onClick={() => onNavigateTab('laboratory')}
              className="text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1 cursor-pointer"
            >
              All Tests <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {recentLabs.map((lab) => (
              <div
                key={lab.Test_ID}
                onClick={() => onSelectPatient(lab.Patient_ID)}
                className="p-4 hover:bg-slate-50 transition-colors flex items-center justify-between gap-4 cursor-pointer group"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 group-hover:text-teal-700">
                      {lab.Test_Name}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">#{lab.Test_ID}</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Patient: <strong className="text-slate-700">{lab.patient?.Name}</strong> • {lab.Test_Date}
                  </div>
                  <div className="text-[11px] text-slate-700 font-mono mt-1 line-clamp-1">
                    {lab.Result}
                  </div>
                </div>

                <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2 py-1 rounded-md shrink-0">
                  View
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* PENDING PAYMENTS */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-amber-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">Pending Payments</h2>
            </div>
            <button
              onClick={() => onNavigateTab('billing')}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
            >
              Billing Ledger <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {pendingBills.length > 0 ? (
              pendingBills.map((bill) => (
                <div
                  key={bill.Bill_ID}
                  className="p-4 hover:bg-slate-50 transition-colors flex items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">
                        {bill.patient?.Name}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">Bill #{bill.Bill_ID}</span>
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      Date: {bill.Bill_Date} • Phone: {bill.patient?.Phone_Number}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="text-sm font-black text-amber-700">
                        ₹{bill.Total_Amount.toLocaleString()}
                      </div>
                      <Badge variant="Pending" size="sm">Pending</Badge>
                    </div>

                    <button
                      onClick={() => handlePayPendingBill(bill.Bill_ID)}
                      className="px-2.5 py-1 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors cursor-pointer"
                    >
                      Pay
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-xs text-slate-400">
                All bills are currently settled. No pending payments.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
