import React, { useState } from 'react';
import { Plus, Search, Pill, ChevronRight, Stethoscope } from 'lucide-react';
import { prescriptionService } from '../../services/prescriptionService';

interface PrescriptionsViewProps {
  onSelectPatient: (patientId: number) => void;
  onOpenAddModal: () => void;
}

export const PrescriptionsView: React.FC<PrescriptionsViewProps> = ({
  onSelectPatient,
  onOpenAddModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const prescriptions = prescriptionService.getAllJoined();

  const filtered = prescriptions.filter(
    (p) =>
      p.Medicine_Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.Dosage.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.patient?.Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.doctor?.Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(p.Prescription_ID).includes(searchQuery)
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            Prescriptions
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
              {prescriptions.length} Records
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Prescription registry joining Patient and Doctor entities in MySQL.
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          + Add Prescription
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search prescriptions by medicine name, patient, dosage, or doctor..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Prescriptions Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Prescriptions Table (MySQL <code className="text-teal-700 font-mono">Prescription</code>)
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filtered.length} of {prescriptions.length}
          </span>
        </div>

        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider bg-slate-50/60">
                  <th className="py-3 px-4">Rx ID</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Prescribed Doctor</th>
                  <th className="py-3 px-4">Medicine Name</th>
                  <th className="py-3 px-4">Dosage</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((rx) => (
                  <tr key={rx.Prescription_ID} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-600">#{rx.Prescription_ID}</td>
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      <button
                        onClick={() => onSelectPatient(rx.Patient_ID)}
                        className="hover:text-teal-700 hover:underline cursor-pointer text-left"
                      >
                        {rx.patient?.Name || `Patient #${rx.Patient_ID}`}
                      </button>
                      <div className="text-[11px] text-slate-400">ID: #{rx.Patient_ID}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <Stethoscope className="w-3.5 h-3.5 text-teal-600" />
                        {rx.doctor?.Name || `Dr. #${rx.Doctor_ID}`}
                      </div>
                      <div className="text-[11px] text-slate-500">{rx.doctor?.Department}</div>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-1.5">
                      <Pill className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      {rx.Medicine_Name}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-700 font-mono">{rx.Dosage}</td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => onSelectPatient(rx.Patient_ID)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-600 hover:text-white rounded-lg border border-teal-200 transition-colors cursor-pointer"
                      >
                        View Patient
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-xs text-slate-400">
            No prescriptions found matching your search.
          </div>
        )}
      </div>
    </div>
  );
};
