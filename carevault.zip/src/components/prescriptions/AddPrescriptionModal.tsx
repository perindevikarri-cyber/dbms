import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { prescriptionService } from '../../services/prescriptionService';
import { patientService } from '../../services/patientService';
import { doctorService } from '../../services/doctorService';
import { Prescription } from '../../types/database';

interface AddPrescriptionModalProps {
  isOpen: boolean;
  preselectedPatientId?: number | null;
  onClose: () => void;
  onSuccess: (prescription: Prescription) => void;
}

export const AddPrescriptionModal: React.FC<AddPrescriptionModalProps> = ({
  isOpen,
  preselectedPatientId,
  onClose,
  onSuccess,
}) => {
  const patients = patientService.getAll();
  const doctors = doctorService.getAll();

  const [formData, setFormData] = useState({
    Patient_ID: preselectedPatientId || (patients[0]?.Patient_ID ?? 1),
    Doctor_ID: doctors[0]?.Doctor_ID ?? 1,
    Medicine_Name: '',
    Dosage: '',
  });

  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.Medicine_Name.trim() || !formData.Dosage.trim()) {
      setError('Medicine name and dosage instructions are required.');
      return;
    }

    const created = prescriptionService.create({
      Patient_ID: Number(formData.Patient_ID),
      Doctor_ID: Number(formData.Doctor_ID),
      Medicine_Name: formData.Medicine_Name.trim(),
      Dosage: formData.Dosage.trim(),
    });

    onSuccess(created);
    onClose();
    setFormData({
      Patient_ID: patients[0]?.Patient_ID ?? 1,
      Doctor_ID: doctors[0]?.Doctor_ID ?? 1,
      Medicine_Name: '',
      Dosage: '',
    });
    setError('');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Add Prescription"
      subtitle="Creates a prescription entry in MySQL Prescription table"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="p-2.5 rounded-lg bg-rose-50 text-rose-700 text-xs font-semibold">{error}</div>}

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Patient *
          </label>
          <select
            value={formData.Patient_ID}
            onChange={(e) => setFormData({ ...formData, Patient_ID: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            {patients.map((p) => (
              <option key={p.Patient_ID} value={p.Patient_ID}>
                {p.Name} (ID: #{p.Patient_ID})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Prescribing Doctor *
          </label>
          <select
            value={formData.Doctor_ID}
            onChange={(e) => setFormData({ ...formData, Doctor_ID: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            {doctors.map((d) => (
              <option key={d.Doctor_ID} value={d.Doctor_ID}>
                {d.Name} — {d.Department}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Medicine Name *
          </label>
          <input
            type="text"
            value={formData.Medicine_Name}
            onChange={(e) => setFormData({ ...formData, Medicine_Name: e.target.value })}
            placeholder="e.g. Amlodipine or Pantoprazole"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Dosage & Frequency *
          </label>
          <input
            type="text"
            value={formData.Dosage}
            onChange={(e) => setFormData({ ...formData, Dosage: e.target.value })}
            placeholder="e.g. 5 mg once daily or 40 mg before breakfast"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
          />
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs cursor-pointer"
          >
            Save Prescription
          </button>
        </div>
      </form>
    </Modal>
  );
};
