import React, { useState } from 'react';
import { Plus, Search, FlaskConical, ChevronRight } from 'lucide-react';
import { laboratoryService } from '../../services/laboratoryService';

interface LaboratoryViewProps {
  onSelectPatient: (patientId: number) => void;
  onOpenAddModal: () => void;
}

export const LaboratoryView: React.FC<LaboratoryViewProps> = ({
  onSelectPatient,
  onOpenAddModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const tests = laboratoryService.getAllJoined();

  const filtered = tests.filter(
    (t) =>
      t.Test_Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.Result.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.patient?.Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(t.Test_ID).includes(searchQuery)
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            Laboratory & Diagnostics
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
              {tests.length} Reports
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Pathology and diagnostic investigation records from Laboratory_Test table.
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          + Add Laboratory Test
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search test by name, result findings, or patient..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Laboratory Tests Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Laboratory Table (MySQL <code className="text-teal-700 font-mono">Laboratory_Test</code>)
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filtered.length} of {tests.length}
          </span>
        </div>

        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider bg-slate-50/60">
                  <th className="py-3 px-4">Test ID</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Test Name</th>
                  <th className="py-3 px-4">Test Date</th>
                  <th className="py-3 px-4">Stored Diagnostic Result</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((t) => (
                  <tr key={t.Test_ID} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-600">#{t.Test_ID}</td>
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      <button
                        onClick={() => onSelectPatient(t.Patient_ID)}
                        className="hover:text-teal-700 hover:underline cursor-pointer text-left"
                      >
                        {t.patient?.Name || `Patient #${t.Patient_ID}`}
                      </button>
                      <div className="text-[11px] text-slate-400">ID: #{t.Patient_ID}</div>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-1.5">
                      <FlaskConical className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      {t.Test_Name}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-700">{t.Test_Date}</td>
                    <td className="py-3.5 px-4 font-mono text-slate-800 max-w-md">{t.Result}</td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => onSelectPatient(t.Patient_ID)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-600 hover:text-white rounded-lg border border-teal-200 transition-colors cursor-pointer"
                      >
                        View Patient
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-xs text-slate-400">
            No laboratory tests found.
          </div>
        )}
      </div>
    </div>
  );
};
