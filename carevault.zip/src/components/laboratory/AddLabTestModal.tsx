import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { laboratoryService } from '../../services/laboratoryService';
import { patientService } from '../../services/patientService';
import { LaboratoryTest } from '../../types/database';

interface AddLabTestModalProps {
  isOpen: boolean;
  preselectedPatientId?: number | null;
  onClose: () => void;
  onSuccess: (test: LaboratoryTest) => void;
}

export const AddLabTestModal: React.FC<AddLabTestModalProps> = ({
  isOpen,
  preselectedPatientId,
  onClose,
  onSuccess,
}) => {
  const patients = patientService.getAll();

  const [formData, setFormData] = useState({
    Patient_ID: preselectedPatientId || (patients[0]?.Patient_ID ?? 1),
    Test_Name: '',
    Test_Date: new Date().toISOString().split('T')[0],
    Result: '',
  });

  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.Test_Name.trim() || !formData.Result.trim()) {
      setError('Test name and laboratory result are required.');
      return;
    }

    const created = laboratoryService.create({
      Patient_ID: Number(formData.Patient_ID),
      Test_Name: formData.Test_Name.trim(),
      Test_Date: formData.Test_Date,
      Result: formData.Result.trim(),
    });

    onSuccess(created);
    onClose();
    setFormData({
      Patient_ID: patients[0]?.Patient_ID ?? 1,
      Test_Name: '',
      Test_Date: new Date().toISOString().split('T')[0],
      Result: '',
    });
    setError('');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Add Laboratory Test"
      subtitle="Inserts diagnostic report into MySQL Laboratory_Test table"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="p-2.5 rounded-lg bg-rose-50 text-rose-700 text-xs font-semibold">{error}</div>}

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Patient *
          </label>
          <select
            value={formData.Patient_ID}
            onChange={(e) => setFormData({ ...formData, Patient_ID: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            {patients.map((p) => (
              <option key={p.Patient_ID} value={p.Patient_ID}>
                {p.Name} (ID: #{p.Patient_ID})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Laboratory Test Name *
          </label>
          <input
            type="text"
            value={formData.Test_Name}
            onChange={(e) => setFormData({ ...formData, Test_Name: e.target.value })}
            placeholder="e.g. Lipid Profile & ECG or Complete Blood Count (CBC)"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Test Date *
          </label>
          <input
            type="date"
            value={formData.Test_Date}
            onChange={(e) => setFormData({ ...formData, Test_Date: e.target.value })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Diagnostic Test Result *
          </label>
          <textarea
            rows={3}
            value={formData.Result}
            onChange={(e) => setFormData({ ...formData, Result: e.target.value })}
            placeholder="e.g. Total Cholesterol 195 mg/dL (Normal <200), Normal Sinus Rhythm"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 font-mono"
          />
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs cursor-pointer"
          >
            Save Lab Test
          </button>
        </div>
      </form>
    </Modal>
  );
};
