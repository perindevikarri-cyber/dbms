import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { billingService } from '../../services/billingService';
import { patientService } from '../../services/patientService';
import { Billing } from '../../types/database';

interface CreateBillModalProps {
  isOpen: boolean;
  preselectedPatientId?: number | null;
  onClose: () => void;
  onSuccess: (bill: Billing) => void;
}

export const CreateBillModal: React.FC<CreateBillModalProps> = ({
  isOpen,
  preselectedPatientId,
  onClose,
  onSuccess,
}) => {
  const patients = patientService.getAll();

  const [formData, setFormData] = useState({
    Patient_ID: preselectedPatientId || (patients[0]?.Patient_ID ?? 1),
    Total_Amount: '',
    Bill_Date: new Date().toISOString().split('T')[0],
    Payment_Status: 'Pending' as Billing['Payment_Status'],
  });

  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Number(formData.Total_Amount);
    if (!amount || amount <= 0) {
      setError('Please provide a valid bill amount.');
      return;
    }

    const created = billingService.create({
      Patient_ID: Number(formData.Patient_ID),
      Total_Amount: amount,
      Bill_Date: formData.Bill_Date,
      Payment_Status: formData.Payment_Status,
    });

    onSuccess(created);
    onClose();
    setFormData({
      Patient_ID: patients[0]?.Patient_ID ?? 1,
      Total_Amount: '',
      Bill_Date: new Date().toISOString().split('T')[0],
      Payment_Status: 'Pending',
    });
    setError('');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create New Hospital Bill"
      subtitle="Inserts invoice ledger entry into MySQL Billing table"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="p-2.5 rounded-lg bg-rose-50 text-rose-700 text-xs font-semibold">{error}</div>}

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Patient *
          </label>
          <select
            value={formData.Patient_ID}
            onChange={(e) => setFormData({ ...formData, Patient_ID: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            {patients.map((p) => (
              <option key={p.Patient_ID} value={p.Patient_ID}>
                {p.Name} (ID: #{p.Patient_ID})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Total Amount (₹) *
          </label>
          <input
            type="number"
            min="100"
            step="50"
            value={formData.Total_Amount}
            onChange={(e) => setFormData({ ...formData, Total_Amount: e.target.value })}
            placeholder="e.g. 4500"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 font-bold"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Bill Date *
          </label>
          <input
            type="date"
            value={formData.Bill_Date}
            onChange={(e) => setFormData({ ...formData, Bill_Date: e.target.value })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Initial Payment Status *
          </label>
          <select
            value={formData.Payment_Status}
            onChange={(e) =>
              setFormData({ ...formData, Payment_Status: e.target.value as Billing['Payment_Status'] })
            }
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            <option value="Pending">Pending</option>
            <option value="Paid">Paid</option>
          </select>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs cursor-pointer"
          >
            Create Bill
          </button>
        </div>
      </form>
    </Modal>
  );
};
