import React, { useState, useMemo } from 'react';
import { Plus, Search, Receipt, CheckCircle, Filter, ChevronRight, ArrowUpDown } from 'lucide-react';
import { billingService } from '../../services/billingService';
import { Badge } from '../common/Badge';

interface BillingViewProps {
  onSelectPatient: (patientId: number) => void;
  onOpenCreateBill: () => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const BillingView: React.FC<BillingViewProps> = ({
  onSelectPatient,
  onOpenCreateBill,
  onNotify,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Paid' | 'Pending'>('All');

  const summary = billingService.getSummary();
  const allBills = billingService.getAllJoined();

  const filteredBills = useMemo(() => {
    return allBills.filter((b) => {
      const matchStatus = statusFilter === 'All' || b.Payment_Status === statusFilter;
      const matchSearch =
        !searchQuery ||
        b.patient?.Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        String(b.Bill_ID).includes(searchQuery) ||
        String(b.Total_Amount).includes(searchQuery);

      return matchStatus && matchSearch;
    });
  }, [allBills, statusFilter, searchQuery]);

  const handleToggleStatus = (billId: number, currentStatus: 'Paid' | 'Pending') => {
    const nextStatus = currentStatus === 'Pending' ? 'Paid' : 'Pending';
    billingService.updateStatus(billId, nextStatus);
    onNotify('success', `Bill #${billId} status updated to ${nextStatus}.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            Billing & Invoices
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
              {allBills.length} Invoices
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Financial ledger tracking patient invoices and settlement status in MySQL Billing table.
          </p>
        </div>

        <button
          onClick={onOpenCreateBill}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          + Create Bill
        </button>
      </div>

      {/* 3 Summary KPI Cards: Total Billed, Total Paid, Total Pending */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
            <span>Total Billed</span>
            <Receipt className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">
            ₹{summary.totalBilled.toLocaleString()}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Across {summary.totalCount} invoices
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-emerald-200/90 p-5 shadow-xs bg-emerald-50/20">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-emerald-800">
            <span>Total Paid (Revenue)</span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700 mt-2">
            ₹{summary.totalPaid.toLocaleString()}
          </div>
          <div className="text-xs text-emerald-700/80 mt-1">
            {summary.paidCount} settled accounts
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-amber-200/90 p-5 shadow-xs bg-amber-50/20">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-amber-800">
            <span>Total Pending Due</span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
          </div>
          <div className="text-2xl font-black text-amber-700 mt-2">
            ₹{summary.totalPending.toLocaleString()}
          </div>
          <div className="text-xs text-amber-700/80 mt-1">
            {summary.pendingCount} outstanding invoices
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by patient name, bill ID, or amount..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-medium">Status Filter:</span>
          <div className="flex gap-1 bg-slate-100 p-1 rounded-lg">
            {(['All', 'Paid', 'Pending'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                  statusFilter === s
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bills Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Billing Table (MySQL <code className="text-teal-700 font-mono">Billing</code>)
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredBills.length} of {allBills.length}
          </span>
        </div>

        {filteredBills.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider bg-slate-50/60">
                  <th className="py-3 px-4">Bill ID</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Bill Date</th>
                  <th className="py-3 px-4">Total Amount</th>
                  <th className="py-3 px-4">Payment Status</th>
                  <th className="py-3 px-4 text-right">Status Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredBills.map((bill) => (
                  <tr key={bill.Bill_ID} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-600">#{bill.Bill_ID}</td>
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      <button
                        onClick={() => onSelectPatient(bill.Patient_ID)}
                        className="hover:text-teal-700 hover:underline cursor-pointer text-left"
                      >
                        {bill.patient?.Name || `Patient #${bill.Patient_ID}`}
                      </button>
                      <div className="text-[11px] text-slate-400 font-mono">ID: #{bill.Patient_ID}</div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-700">{bill.Bill_Date}</td>
                    <td className="py-3.5 px-4 font-black text-slate-900 text-sm">
                      ₹{bill.Total_Amount.toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4">
                      <Badge variant={bill.Payment_Status} dot size="sm">
                        {bill.Payment_Status}
                      </Badge>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => handleToggleStatus(bill.Bill_ID, bill.Payment_Status)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                          bill.Payment_Status === 'Pending'
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        <ArrowUpDown className="w-3 h-3" />
                        <span>
                          {bill.Payment_Status === 'Pending' ? 'Mark as Paid' : 'Revert to Pending'}
                        </span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-xs text-slate-400">
            No bills match your current filter.
          </div>
        )}
      </div>
    </div>
  );
};
