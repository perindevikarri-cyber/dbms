import React, { useState, useMemo } from 'react';
import { BedDouble, CheckCircle2, AlertCircle, Building2, Filter, ArrowUpDown } from 'lucide-react';
import { roomService } from '../../services/roomService';
import { Room } from '../../types/database';
import { Badge } from '../common/Badge';

interface RoomsViewProps {
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const RoomsView: React.FC<RoomsViewProps> = ({ onNotify }) => {
  const [availabilityFilter, setAvailabilityFilter] = useState<'All' | 'Available' | 'Occupied'>('All');
  const [floorFilter, setFloorFilter] = useState<string>('All');

  const allRooms = roomService.getAll();
  const stats = roomService.getStats();

  const filteredRooms = useMemo(() => {
    return allRooms.filter((r) => {
      const matchAvail = availabilityFilter === 'All' || r.Availability === availabilityFilter;
      const matchFloor = floorFilter === 'All' || String(r.Floor) === floorFilter;
      return matchAvail && matchFloor;
    });
  }, [allRooms, availabilityFilter, floorFilter]);

  const handleToggle = (roomId: string, current: Room['Availability']) => {
    const updated = roomService.toggleAvailability(roomId);
    if (updated) {
      onNotify(
        'success',
        `Room ${updated.Room_Number} is now marked as ${updated.Availability}.`
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            Hospital Rooms & Wards
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
              {stats.total} Inpatient Units
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Ward allocation, ICU beds, and room occupancy status in MySQL Room table.
          </p>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
            <span>Total Hospital Beds</span>
            <BedDouble className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{stats.total}</div>
          <div className="text-xs text-slate-500 mt-1">Across 4 facility floors</div>
        </div>

        <div className="bg-white rounded-2xl border border-emerald-200/90 p-5 shadow-xs bg-emerald-50/20">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-emerald-800">
            <span>Available Vacancies</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700 mt-2">{stats.available}</div>
          <div className="text-xs text-emerald-700/80 mt-1">Ready for patient admission</div>
        </div>

        <div className="bg-white rounded-2xl border border-rose-200/90 p-5 shadow-xs bg-rose-50/20">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-rose-800">
            <span>Occupied Beds</span>
            <AlertCircle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black text-rose-700 mt-2">{stats.occupied}</div>
          <div className="text-xs text-rose-700/80 mt-1">Currently assigned to patients</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 font-semibold">
            <Filter className="w-3.5 h-3.5" />
            <span>Availability:</span>
          </div>

          <div className="flex gap-1 bg-slate-100 p-1 rounded-lg">
            {(['All', 'Available', 'Occupied'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setAvailabilityFilter(s)}
                className={`px-3 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                  availabilityFilter === s
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-medium">Floor:</span>
          <select
            value={floorFilter}
            onChange={(e) => setFloorFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-700 focus:outline-hidden"
          >
            <option value="All">All Floors</option>
            <option value="1">Floor 1 (General Ward)</option>
            <option value="2">Floor 2 (Private)</option>
            <option value="3">Floor 3 (ICU)</option>
            <option value="4">Floor 4 (Deluxe)</option>
          </select>
        </div>
      </div>

      {/* Room Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredRooms.map((room) => {
          const isAvailable = room.Availability === 'Available';
          return (
            <div
              key={room.Room_ID}
              className={`bg-white rounded-2xl border p-5 shadow-xs flex flex-col justify-between transition-all ${
                isAvailable ? 'border-emerald-200 hover:border-emerald-400' : 'border-rose-200 hover:border-rose-400'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    {room.Room_ID}
                  </span>
                  <Badge variant={room.Availability} dot size="sm">
                    {room.Availability.toUpperCase()}
                  </Badge>
                </div>

                <div className="flex items-center gap-2 mb-1">
                  <BedDouble className={`w-5 h-5 ${isAvailable ? 'text-emerald-600' : 'text-rose-600'}`} />
                  <h3 className="text-base font-extrabold text-slate-900">
                    Room {room.Room_Number}
                  </h3>
                </div>

                <p className="text-xs font-semibold text-slate-700">{room.Room_Type}</p>

                <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-3 pt-3 border-t border-slate-100">
                  <Building2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Floor {room.Floor}</span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100">
                <button
                  onClick={() => handleToggle(room.Room_ID, room.Availability)}
                  className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                    isAvailable
                      ? 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
                      : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                  }`}
                >
                  <ArrowUpDown className="w-3.5 h-3.5" />
                  {isAvailable ? 'Mark as Occupied' : 'Mark as Available'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
