import React, { useState, useMemo } from 'react';
import { Search, Plus, Filter, User, ChevronRight, Droplet, Phone, MapPin, Sparkles, X } from 'lucide-react';
import { patientService } from '../../services/patientService';
import { Patient } from '../../types/database';

interface PatientsViewProps {
  onViewRecord: (patientId: number) => void;
  onOpenAddModal: () => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const PatientsView: React.FC<PatientsViewProps> = ({
  onViewRecord,
  onOpenAddModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [genderFilter, setGenderFilter] = useState<string>('All');
  const [bloodFilter, setBloodFilter] = useState<string>('All');

  const allPatients = patientService.getAll();

  const filteredPatients = useMemo(() => {
    let result = allPatients;

    if (searchQuery.trim()) {
      result = patientService.search(searchQuery);
    }

    if (genderFilter !== 'All') {
      result = result.filter((p) => p.Gender === genderFilter);
    }

    if (bloodFilter !== 'All') {
      result = result.filter((p) => p.Blood_Group === bloodFilter);
    }

    return result;
  }, [allPatients, searchQuery, genderFilter, bloodFilter]);

  // Exact match highlight for Rahul Kumar / Patient 1
  const highlightPatient = filteredPatients.find(
    (p) =>
      p.Patient_ID === 1 ||
      p.Name.toLowerCase() === 'rahul kumar'
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            Patients
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
              {allPatients.length} Digital Records
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Manage and retrieve digital patient records from MySQL Patient table.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => onViewRecord(1)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-50 text-teal-800 border border-teal-200 hover:bg-teal-100 text-xs font-bold transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-600" />
            Demo: Rahul Kumar
          </button>

          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Patient
          </button>
        </div>
      </div>

      {/* Prominent Search and Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs space-y-4">
        <div className="relative">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center justify-between">
            <span>Primary Retrieval Index (Patient Name or Patient ID)</span>
            {searchQuery && (
              <span className="text-teal-700 font-semibold lowercase">
                Showing results for &ldquo;{searchQuery}&rdquo;
              </span>
            )}
          </div>
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-teal-600 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search patient by name or Patient ID (e.g. Rahul Kumar, 1, Priya, Vijayawada)..."
              className="w-full pl-10 pr-10 py-2.5 bg-slate-50 hover:bg-slate-100/60 focus:bg-white border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 transition-all font-medium"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Filter controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-slate-500 font-medium">
              <Filter className="w-3.5 h-3.5" />
              <span>Filters:</span>
            </div>

            {/* Gender filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">Gender:</span>
              <select
                value={genderFilter}
                onChange={(e) => setGenderFilter(e.target.value)}
                className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-hidden focus:border-teal-500"
              >
                <option value="All">All Genders</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* Blood group filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">Blood Group:</span>
              <select
                value={bloodFilter}
                onChange={(e) => setBloodFilter(e.target.value)}
                className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-hidden focus:border-teal-500"
              >
                <option value="All">All Groups</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
              </select>
            </div>
          </div>

          {(genderFilter !== 'All' || bloodFilter !== 'All' || searchQuery) && (
            <button
              onClick={() => {
                setGenderFilter('All');
                setBloodFilter('All');
                setSearchQuery('');
              }}
              className="text-xs text-teal-700 hover:text-teal-800 font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Prominent Instant Result Spotlight if search matched Rahul Kumar or a specific patient */}
      {searchQuery && highlightPatient && (
        <div className="bg-gradient-to-r from-teal-500/10 via-sky-500/10 to-transparent border border-teal-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-teal-600 text-white font-extrabold text-lg flex items-center justify-center shrink-0 shadow-xs">
              {highlightPatient.Name.charAt(0)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-base font-black text-slate-900">{highlightPatient.Name}</span>
                <span className="px-2 py-0.5 rounded bg-teal-100 text-teal-800 font-mono text-xs font-bold">
                  Patient ID: {highlightPatient.Patient_ID}
                </span>
                <span className="px-2 py-0.2 rounded-full bg-rose-50 text-rose-700 text-xs font-bold border border-rose-200">
                  {highlightPatient.Blood_Group}
                </span>
              </div>
              <div className="text-xs text-slate-600 mt-1 flex flex-wrap items-center gap-3">
                <span>{highlightPatient.Age} years</span>
                <span>•</span>
                <span>{highlightPatient.Gender}</span>
                <span>•</span>
                <span className="flex items-center gap-1 font-mono">
                  <Phone className="w-3 h-3 text-slate-400" />
                  {highlightPatient.Phone_Number}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {highlightPatient.Address}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onViewRecord(highlightPatient.Patient_ID)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
          >
            <span>View Full Record</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Patients Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Registered Patients Table (MySQL <code className="text-teal-700 font-mono">Patient</code>)
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredPatients.length} of {allPatients.length}
          </span>
        </div>

        {filteredPatients.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider bg-slate-50/60">
                  <th className="py-3 px-4">Patient ID</th>
                  <th className="py-3 px-4">Name</th>
                  <th className="py-3 px-4">Age</th>
                  <th className="py-3 px-4">Gender</th>
                  <th className="py-3 px-4">Phone</th>
                  <th className="py-3 px-4">Address</th>
                  <th className="py-3 px-4">Blood Group</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPatients.map((p) => {
                  const isDemoPatient = p.Patient_ID === 1;
                  return (
                    <tr
                      key={p.Patient_ID}
                      className={`hover:bg-teal-50/40 transition-colors ${
                        isDemoPatient ? 'bg-teal-50/20' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-700">
                        P{String(p.Patient_ID).padStart(3, '0')}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          {p.Name}
                          {isDemoPatient && (
                            <span className="px-1.5 py-0.2 rounded bg-teal-100 text-teal-800 text-[10px] font-bold">
                              Demo
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">{p.Age}</td>
                      <td className="py-3.5 px-4 text-slate-700">{p.Gender}</td>
                      <td className="py-3.5 px-4 font-mono text-slate-700">{p.Phone_Number}</td>
                      <td className="py-3.5 px-4 text-slate-700">{p.Address}</td>
                      <td className="py-3.5 px-4">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 font-bold text-[11px] border border-rose-200">
                          <Droplet className="w-2.5 h-2.5 fill-rose-500" />
                          {p.Blood_Group}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => onViewRecord(p.Patient_ID)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-600 hover:text-white border border-teal-200 transition-all cursor-pointer"
                        >
                          <span>View Record</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 px-4 text-center">
            <User className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-800">No patient record found.</p>
            <p className="text-xs text-slate-500 mt-1">
              No matching records for your search or filter combination.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setGenderFilter('All');
                setBloodFilter('All');
              }}
              className="mt-3 px-3.5 py-1.5 text-xs font-semibold text-teal-700 bg-teal-50 border border-teal-200 rounded-lg hover:bg-teal-100 cursor-pointer"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
