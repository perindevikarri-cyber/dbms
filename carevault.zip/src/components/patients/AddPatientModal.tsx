import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { patientService } from '../../services/patientService';
import { Patient } from '../../types/database';

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newPatient: Patient) => void;
}

export const AddPatientModal: React.FC<AddPatientModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [formData, setFormData] = useState({
    Name: '',
    Age: '',
    Gender: 'Male' as Patient['Gender'],
    Phone_Number: '',
    Address: '',
    Blood_Group: 'O+' as Patient['Blood_Group'],
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.Name.trim()) errs.Name = 'Patient Name is required';
    if (!formData.Age || isNaN(Number(formData.Age)) || Number(formData.Age) <= 0) {
      errs.Age = 'Valid age is required';
    }
    if (!formData.Phone_Number.trim() || formData.Phone_Number.length < 7) {
      errs.Phone_Number = 'Valid phone number is required';
    }
    if (!formData.Address.trim()) errs.Address = 'Address is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const created = patientService.create({
      Name: formData.Name.trim(),
      Age: Number(formData.Age),
      Gender: formData.Gender,
      Phone_Number: formData.Phone_Number.trim(),
      Address: formData.Address.trim(),
      Blood_Group: formData.Blood_Group,
    });

    onSuccess(created);
    onClose();
    setFormData({
      Name: '',
      Age: '',
      Gender: 'Male',
      Phone_Number: '',
      Address: '',
      Blood_Group: 'O+',
    });
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Add New Patient"
      subtitle="Creates a digital record in the MySQL Patient table"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Patient Full Name *
          </label>
          <input
            type="text"
            value={formData.Name}
            onChange={(e) => setFormData({ ...formData, Name: e.target.value })}
            placeholder="e.g. Rahul Kumar"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
          />
          {errors.Name && <p className="text-xs text-rose-500 mt-1">{errors.Name}</p>}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Age *
            </label>
            <input
              type="number"
              min="1"
              max="120"
              value={formData.Age}
              onChange={(e) => setFormData({ ...formData, Age: e.target.value })}
              placeholder="e.g. 24"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
            />
            {errors.Age && <p className="text-xs text-rose-500 mt-1">{errors.Age}</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Gender *
            </label>
            <select
              value={formData.Gender}
              onChange={(e) => setFormData({ ...formData, Gender: e.target.value as Patient['Gender'] })}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
            >
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Blood Group *
            </label>
            <select
              value={formData.Blood_Group}
              onChange={(e) =>
                setFormData({ ...formData, Blood_Group: e.target.value as Patient['Blood_Group'] })
              }
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
            >
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Phone Number *
            </label>
            <input
              type="text"
              value={formData.Phone_Number}
              onChange={(e) => setFormData({ ...formData, Phone_Number: e.target.value })}
              placeholder="e.g. 9876543210"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 font-mono"
            />
            {errors.Phone_Number && <p className="text-xs text-rose-500 mt-1">{errors.Phone_Number}</p>}
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            City / Address *
          </label>
          <input
            type="text"
            value={formData.Address}
            onChange={(e) => setFormData({ ...formData, Address: e.target.value })}
            placeholder="e.g. Kakinada"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
          />
          {errors.Address && <p className="text-xs text-rose-500 mt-1">{errors.Address}</p>}
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Save Patient
          </button>
        </div>
      </form>
    </Modal>
  );
};
