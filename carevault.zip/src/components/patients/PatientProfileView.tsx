import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Calendar,
  FileHeart,
  Pill,
  FlaskConical,
  Receipt,
  User,
  Phone,
  MapPin,
  Droplet,
  Clock,
  CheckCircle2,
  AlertCircle,
  Edit,
  Plus,
  Info,
  CreditCard,
  Stethoscope,
} from 'lucide-react';
import { patientService } from '../../services/patientService';
import { billingService } from '../../services/billingService';
import { CompletePatientProfile } from '../../types/database';
import { Badge } from '../common/Badge';

interface PatientProfileViewProps {
  patientId: number;
  onBack: () => void;
  onEditPatient: (patientId: number) => void;
  onAddAppointment?: (patientId: number) => void;
  onAddRecord?: (patientId: number) => void;
  onAddPrescription?: (patientId: number) => void;
  onAddLabTest?: (patientId: number) => void;
  onAddBill?: (patientId: number) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

type ProfileTab = 'overview' | 'appointments' | 'medical-records' | 'prescriptions' | 'laboratory' | 'billing';

export const PatientProfileView: React.FC<PatientProfileViewProps> = ({
  patientId,
  onBack,
  onEditPatient,
  onAddAppointment,
  onAddRecord,
  onAddPrescription,
  onAddLabTest,
  onAddBill,
  onNotify,
}) => {
  const [profile, setProfile] = useState<CompletePatientProfile | null>(null);
  const [activeTab, setActiveTab] = useState<ProfileTab>('overview');

  const refreshProfile = () => {
    const data = patientService.getCompleteProfile(patientId);
    setProfile(data);
  };

  useEffect(() => {
    refreshProfile();
  }, [patientId]);

  if (!profile) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-800">Unable to find patient record</h3>
        <p className="text-sm text-slate-500 mt-1">Patient ID #{patientId} does not exist in the database.</p>
        <button
          onClick={onBack}
          className="mt-5 inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Patients List
        </button>
      </div>
    );
  }

  const { patient, appointments, medicalRecords, prescriptions, laboratoryTests, bills, summary } = profile;

  const handlePayBill = (billId: number) => {
    billingService.updateStatus(billId, 'Paid');
    refreshProfile();
    onNotify('success', `Bill #${billId} updated to Paid successfully.`);
  };

  return (
    <div className="space-y-6">
      {/* Top Navigation & Back */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Patients List
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onEditPatient(patient.Patient_ID)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            <Edit className="w-3.5 h-3.5 text-slate-500" />
            Edit Profile
          </button>
        </div>
      </div>

      {/* Main Patient Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-teal-500 to-sky-600 text-white font-extrabold text-2xl sm:text-3xl flex items-center justify-center shadow-md shadow-teal-500/10 shrink-0">
              {patient.Name.charAt(0)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  {patient.Name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-lg bg-slate-100 border border-slate-200 text-slate-700 font-mono text-xs font-bold">
                  ID: P{String(patient.Patient_ID).padStart(3, '0')}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-1">
                  <Droplet className="w-3 h-3 fill-rose-500" />
                  {patient.Blood_Group}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-y-1 gap-x-4 mt-2 text-xs sm:text-sm text-slate-600 font-medium">
                <span>{patient.Age} years</span>
                <span>•</span>
                <span>{patient.Gender}</span>
                <span>•</span>
                <span className="flex items-center gap-1 text-slate-600">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  {patient.Address}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1 text-slate-600 font-mono">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  {patient.Phone_Number}
                </span>
              </div>
            </div>
          </div>

          {/* Quick status banner */}
          <div className="flex flex-col sm:items-end justify-center pt-3 md:pt-0 border-t md:border-t-0 border-slate-100">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Centralized Digital Status
            </span>
            <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1.5 mt-0.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Unified Record Verified (MySQL 8.0)
            </span>
            {patient.Patient_ID === 1 && (
              <span className="mt-1 px-2 py-0.5 bg-teal-50 border border-teal-200 text-teal-800 text-[10px] font-bold rounded-md uppercase tracking-wider">
                Primary Demo Patient
              </span>
            )}
          </div>
        </div>

        {/* 5 Summary KPI Metrics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-5 border-t border-slate-100">
          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-500 uppercase">Age</span>
            <div className="text-lg font-black text-slate-900 mt-0.5">{patient.Age} yrs</div>
          </div>

          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-500 uppercase">Blood Group</span>
            <div className="text-lg font-black text-rose-700 mt-0.5">{patient.Blood_Group}</div>
          </div>

          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-500 uppercase">Appointments</span>
            <div className="text-lg font-black text-slate-900 mt-0.5">{summary.totalAppointments}</div>
          </div>

          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-500 uppercase">Medical Records</span>
            <div className="text-lg font-black text-slate-900 mt-0.5">{summary.totalRecords}</div>
          </div>

          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-100 col-span-2 sm:col-span-1">
            <span className="text-[11px] font-semibold text-slate-500 uppercase">Pending Bills</span>
            <div
              className={`text-lg font-black mt-0.5 ${
                summary.totalPending > 0 ? 'text-amber-600' : 'text-emerald-700'
              }`}
            >
              ₹{summary.totalPending.toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="border-b border-slate-200">
        <nav className="flex space-x-2 overflow-x-auto pb-px">
          {[
            { id: 'overview', label: 'Overview', icon: User },
            { id: 'appointments', label: `Appointments (${appointments.length})`, icon: Calendar },
            { id: 'medical-records', label: `Medical Records (${medicalRecords.length})`, icon: FileHeart },
            { id: 'prescriptions', label: `Prescriptions (${prescriptions.length})`, icon: Pill },
            { id: 'laboratory', label: `Laboratory (${laboratoryTests.length})`, icon: FlaskConical },
            { id: 'billing', label: `Billing (${bills.length})`, icon: Receipt },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as ProfileTab)}
                className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
                  isActive
                    ? 'border-teal-600 text-teal-700 bg-teal-50/50 rounded-t-lg'
                    : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-teal-600' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Tab 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Personal Information Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <User className="w-4 h-4 text-teal-600" />
                Personal Information
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">Patient_ID: {patient.Patient_ID}</span>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-slate-500 font-medium">Patient ID</span>
                <p className="text-slate-900 font-mono font-bold mt-0.5">
                  {patient.Patient_ID} (P{String(patient.Patient_ID).padStart(3, '0')})
                </p>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Full Name</span>
                <p className="text-slate-900 font-bold mt-0.5">{patient.Name}</p>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Age</span>
                <p className="text-slate-900 font-bold mt-0.5">{patient.Age} years</p>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Gender</span>
                <p className="text-slate-900 font-bold mt-0.5">{patient.Gender}</p>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Phone Number</span>
                <p className="text-slate-900 font-bold font-mono mt-0.5">{patient.Phone_Number}</p>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Blood Group</span>
                <p className="text-rose-700 font-bold mt-0.5">{patient.Blood_Group}</p>
              </div>
              <div className="col-span-2">
                <span className="text-slate-500 font-medium">Address</span>
                <p className="text-slate-900 font-bold mt-0.5">{patient.Address}</p>
              </div>
            </div>
          </div>

          {/* Latest Medical Record Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <FileHeart className="w-4 h-4 text-sky-600" />
                Latest Medical Record
              </h3>
              {summary.latestRecord && (
                <span className="text-[11px] text-slate-400 font-mono">Record #{summary.latestRecord.Record_ID}</span>
              )}
            </div>

            {summary.latestRecord ? (
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-500 font-medium">Diagnosis</span>
                  <p className="text-slate-900 font-bold mt-0.5 text-sm">{summary.latestRecord.Diagnosis}</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Treatment</span>
                  <p className="text-slate-700 leading-relaxed mt-0.5">{summary.latestRecord.Treatment}</p>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-slate-600">
                  <div>
                    <span className="text-[11px] text-slate-400 font-medium">Admission Date</span>
                    <p className="font-semibold text-slate-800">{summary.latestRecord.Admission_Date}</p>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400 font-medium">Discharge Date</span>
                    <p className="font-semibold text-slate-800">{summary.latestRecord.Discharge_Date}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-slate-400 text-xs">
                No medical records logged yet for this patient.
              </div>
            )}
          </div>

          {/* Latest Laboratory Result Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <FlaskConical className="w-4 h-4 text-indigo-600" />
                Latest Laboratory Result
              </h3>
              {summary.latestLab && (
                <span className="text-[11px] text-slate-400 font-mono">Test #{summary.latestLab.Test_ID}</span>
              )}
            </div>

            {summary.latestLab ? (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-900 font-bold text-sm">{summary.latestLab.Test_Name}</span>
                  <span className="text-slate-500 font-medium">{summary.latestLab.Test_Date}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Laboratory Result</span>
                  <div className="mt-1 p-3 bg-slate-50 rounded-xl border border-slate-200/80 font-mono text-slate-900 font-medium leading-relaxed">
                    {summary.latestLab.Result}
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-slate-400 text-xs">
                No laboratory tests on record for this patient.
              </div>
            )}
          </div>

          {/* Billing Summary Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-600" />
                Billing Summary
              </h3>
              {summary.latestBill && (
                <Badge variant={summary.latestBill.Payment_Status} dot size="sm">
                  {summary.latestBill.Payment_Status}
                </Badge>
              )}
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100 text-center">
                <div>
                  <span className="text-[11px] text-slate-500 font-medium">Total Billed</span>
                  <div className="text-base font-bold text-slate-900 mt-0.5">₹{summary.totalBilled.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 font-medium">Total Paid</span>
                  <div className="text-base font-bold text-emerald-700 mt-0.5">₹{summary.totalPaid.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 font-medium">Total Pending</span>
                  <div className={`text-base font-bold mt-0.5 ${summary.totalPending > 0 ? 'text-amber-600' : 'text-slate-600'}`}>
                    ₹{summary.totalPending.toLocaleString()}
                  </div>
                </div>
              </div>

              {summary.latestBill && (
                <div className="pt-2 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-500">Latest Bill Date:</span>{' '}
                    <span className="font-semibold text-slate-800">{summary.latestBill.Bill_Date}</span>
                  </div>
                  {summary.latestBill.Payment_Status === 'Pending' && (
                    <button
                      onClick={() => handlePayBill(summary.latestBill!.Bill_ID)}
                      className="px-2.5 py-1 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors cursor-pointer"
                    >
                      Pay ₹{summary.latestBill.Total_Amount} Now
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: APPOINTMENTS */}
      {activeTab === 'appointments' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Appointments for {patient.Name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Connected from <code className="font-mono text-teal-700 font-semibold">Appointment</code> and <code className="font-mono text-teal-700 font-semibold">Doctor</code> tables
              </p>
            </div>
            {onAddAppointment && (
              <button
                onClick={() => onAddAppointment(patient.Patient_ID)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Schedule Appointment
              </button>
            )}
          </div>

          {appointments.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                    <th className="py-2.5 px-3">Appt ID</th>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Time</th>
                    <th className="py-2.5 px-3">Doctor</th>
                    <th className="py-2.5 px-3">Specialization</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {appointments.map((appt) => (
                    <tr key={appt.Appointment_ID} className="hover:bg-slate-50/70">
                      <td className="py-3 px-3 font-mono font-semibold text-slate-600">
                        #{appt.Appointment_ID}
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-900">{appt.Appointment_Date}</td>
                      <td className="py-3 px-3 font-mono text-slate-700">{appt.Appointment_Time}</td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{appt.doctor?.Name || `Dr. ID #${appt.Doctor_ID}`}</div>
                        <div className="text-[11px] text-slate-500">{appt.doctor?.Department}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-700 font-medium">
                        {appt.doctor?.Specialization || '—'}
                      </td>
                      <td className="py-3 px-3">
                        <Badge variant={appt.Status} dot size="sm">
                          {appt.Status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-10 text-center text-xs text-slate-400">
              No appointments found for this patient.
            </div>
          )}
        </div>
      )}

      {/* Tab 3: MEDICAL RECORDS */}
      {activeTab === 'medical-records' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Medical History & Admissions</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Retrieved from <code className="font-mono text-teal-700 font-semibold">Medical_Record</code> table
              </p>
            </div>
            {onAddRecord && (
              <button
                onClick={() => onAddRecord(patient.Patient_ID)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Medical Record
              </button>
            )}
          </div>

          {medicalRecords.length > 0 ? (
            <div className="space-y-4">
              {medicalRecords.map((record) => (
                <div
                  key={record.Record_ID}
                  className="bg-slate-50/70 border border-slate-200 rounded-xl p-4.5 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-sky-100 text-sky-800">
                        Record #{record.Record_ID}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900">{record.Diagnosis}</h4>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        Admitted: <strong className="text-slate-700">{record.Admission_Date}</strong>
                      </span>
                      <span>→</span>
                      <span>
                        Discharged: <strong className="text-slate-700">{record.Discharge_Date}</strong>
                      </span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      Prescribed Clinical Treatment
                    </span>
                    <p className="text-xs text-slate-800 leading-relaxed mt-1 font-medium bg-white p-3 rounded-lg border border-slate-200/80">
                      {record.Treatment}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-10 text-center text-xs text-slate-400">
              No medical records registered for this patient.
            </div>
          )}
        </div>
      )}

      {/* Tab 4: PRESCRIPTIONS */}
      {activeTab === 'prescriptions' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Prescriptions</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Relational JOIN between <code className="font-mono text-teal-700 font-semibold">Prescription</code>, <code className="font-mono text-teal-700 font-semibold">Patient</code> and <code className="font-mono text-teal-700 font-semibold">Doctor</code>
              </p>
            </div>
            {onAddPrescription && (
              <button
                onClick={() => onAddPrescription(patient.Patient_ID)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Prescription
              </button>
            )}
          </div>

          {prescriptions.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {prescriptions.map((rx) => (
                <div
                  key={rx.Prescription_ID}
                  className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-mono text-[11px] font-bold px-2 py-0.5 rounded bg-teal-100 text-teal-900">
                        Rx #{rx.Prescription_ID}
                      </span>
                      <div className="flex items-center gap-1 text-xs text-slate-600">
                        <Stethoscope className="w-3.5 h-3.5 text-teal-600" />
                        <span className="font-semibold">{rx.doctor?.Name || `Dr. #${rx.Doctor_ID}`}</span>
                      </div>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Pill className="w-4 h-4 text-teal-600 shrink-0" />
                      {rx.Medicine_Name}
                    </h4>

                    <div className="mt-3 p-2.5 bg-white rounded-lg border border-slate-200/80">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                        Dosage Instructions
                      </span>
                      <p className="text-xs font-semibold text-slate-800 mt-0.5">{rx.Dosage}</p>
                    </div>
                  </div>

                  <div className="mt-3 text-[11px] text-slate-500 font-medium">
                    Department: {rx.doctor?.Department || 'Medical Staff'}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-10 text-center text-xs text-slate-400">
              No prescriptions registered for this patient.
            </div>
          )}
        </div>
      )}

      {/* Tab 5: LABORATORY */}
      {activeTab === 'laboratory' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Laboratory & Diagnostic Reports</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Retrieved directly from <code className="font-mono text-teal-700 font-semibold">Laboratory_Test</code> table
              </p>
            </div>
            {onAddLabTest && (
              <button
                onClick={() => onAddLabTest(patient.Patient_ID)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Lab Test
              </button>
            )}
          </div>

          {laboratoryTests.length > 0 ? (
            <div className="divide-y divide-slate-100">
              {laboratoryTests.map((lab) => (
                <div key={lab.Test_ID} className="py-4 first:pt-0 last:pb-0 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700">
                        <FlaskConical className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">{lab.Test_Name}</h4>
                        <span className="text-[11px] font-mono text-slate-400">Test ID: #{lab.Test_ID}</span>
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">
                      {lab.Test_Date}
                    </span>
                  </div>

                  <div className="mt-2 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 leading-relaxed">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block font-sans mb-1">
                      Stored Diagnostic Result
                    </span>
                    {lab.Result}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-10 text-center text-xs text-slate-400">
              No laboratory tests recorded for this patient.
            </div>
          )}
        </div>
      )}

      {/* Tab 6: BILLING */}
      {activeTab === 'billing' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Hospital Billing & Invoice Ledger</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Retrieved from <code className="font-mono text-teal-700 font-semibold">Billing</code> table
              </p>
            </div>
            {onAddBill && (
              <button
                onClick={() => onAddBill(patient.Patient_ID)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Create New Bill
              </button>
            )}
          </div>

          {/* Billing summary cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Billed</span>
              <div className="text-xl font-black text-slate-900 mt-1">₹{summary.totalBilled.toLocaleString()}</div>
            </div>
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
              <span className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider">Total Paid</span>
              <div className="text-xl font-black text-emerald-800 mt-1">₹{summary.totalPaid.toLocaleString()}</div>
            </div>
            <div className="p-4 bg-amber-50 rounded-xl border border-amber-200">
              <span className="text-[11px] font-semibold text-amber-700 uppercase tracking-wider">Total Pending</span>
              <div className="text-xl font-black text-amber-800 mt-1">₹{summary.totalPending.toLocaleString()}</div>
            </div>
          </div>

          {bills.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                    <th className="py-2.5 px-3">Bill ID</th>
                    <th className="py-2.5 px-3">Bill Date</th>
                    <th className="py-2.5 px-3">Total Amount</th>
                    <th className="py-2.5 px-3">Payment Status</th>
                    <th className="py-2.5 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {bills.map((bill) => (
                    <tr key={bill.Bill_ID} className="hover:bg-slate-50/70">
                      <td className="py-3 px-3 font-mono font-semibold text-slate-700">
                        #{bill.Bill_ID}
                      </td>
                      <td className="py-3 px-3 text-slate-800 font-medium">{bill.Bill_Date}</td>
                      <td className="py-3 px-3 font-bold text-slate-900 text-sm">
                        ₹{bill.Total_Amount.toLocaleString()}
                      </td>
                      <td className="py-3 px-3">
                        <Badge variant={bill.Payment_Status} dot size="sm">
                          {bill.Payment_Status}
                        </Badge>
                      </td>
                      <td className="py-3 px-3 text-right">
                        {bill.Payment_Status === 'Pending' ? (
                          <button
                            onClick={() => handlePayBill(bill.Bill_ID)}
                            className="px-3 py-1 rounded-lg text-xs font-bold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 transition-colors cursor-pointer"
                          >
                            Mark Paid
                          </button>
                        ) : (
                          <span className="text-xs text-slate-400 font-medium">Completed</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-10 text-center text-xs text-slate-400">
              No bills found for this patient.
            </div>
          )}
        </div>
      )}

      {/* Demonstration Explanation Banner Required by Project Specifications */}
      <div className="bg-sky-50 border border-sky-200 rounded-2xl p-4.5 flex items-start gap-3.5 text-xs text-sky-950">
        <Info className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold text-sky-900 text-sm">
            DBMS Demonstration Insight: Unified Retrieval
          </span>
          <p className="text-sky-900/90 leading-relaxed">
            &ldquo;All related patient information is organized digitally and can be retrieved from one patient profile instead of manually searching through multiple paper files.&rdquo;
          </p>
          <div className="text-[11px] text-sky-800 font-medium pt-1">
            Connected Entities: Patient #{patient.Patient_ID} ➔ Appointment ({appointments.length}) + Medical_Record ({medicalRecords.length}) + Prescription ({prescriptions.length}) + Laboratory_Test ({laboratoryTests.length}) + Billing ({bills.length}).
          </div>
        </div>
      </div>
    </div>
  );
};
