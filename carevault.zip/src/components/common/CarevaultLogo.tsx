import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

export const CarevaultLogo: React.FC<LogoProps> = ({ size = 'md', showText = true, className = '' }) => {
  const iconDimensions = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-11 h-11',
  }[size];

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Logo mark: Medical Cross embedded within a Database / Vault Folder */}
      <div
        className={`${iconDimensions} rounded-xl bg-gradient-to-br from-teal-600 to-sky-700 p-0.5 shadow-sm flex items-center justify-center text-white shrink-0`}
      >
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full p-1"
        >
          {/* Database cylinder top */}
          <ellipse cx="16" cy="8" rx="10" ry="3.5" stroke="currentColor" strokeWidth="2.2" fill="white" fillOpacity="0.2" />
          {/* Database cylinder body */}
          <path
            d="M6 8V23C6 24.933 10.477 26.5 16 26.5C21.523 26.5 26 24.933 26 23V8"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          {/* Middle partition line */}
          <path
            d="M6 15C6 16.933 10.477 18.5 16 18.5C21.523 18.5 26 16.933 26 15"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeDasharray="2 2"
          />
          {/* Medical Plus Cross in the center */}
          <path
            d="M16 11V21M11 16H21"
            stroke="#38bdf8"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <span className="font-extrabold tracking-tight text-slate-900 text-lg leading-none flex items-center gap-1.5">
            CAREVAULT
            <span className="text-[10px] uppercase font-bold tracking-widest bg-teal-50 text-teal-700 px-1.5 py-0.5 rounded border border-teal-200">
              DBMS
            </span>
          </span>
          <span className="text-[11px] font-medium text-slate-500 tracking-tight leading-tight mt-0.5">
            Digital Hospital Records
          </span>
        </div>
      )}
    </div>
  );
};
