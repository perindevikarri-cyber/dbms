import React from 'react';

type BadgeVariant =
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | 'neutral'
  | 'Scheduled'
  | 'Completed'
  | 'Cancelled'
  | 'Available'
  | 'Occupied'
  | 'Paid'
  | 'Pending';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  dot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  size = 'md',
  dot = false,
}) => {
  const getStyles = () => {
    switch (variant) {
      case 'success':
      case 'Completed':
      case 'Available':
      case 'Paid':
        return {
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
          dotColor: 'bg-emerald-500',
        };
      case 'warning':
      case 'Scheduled':
      case 'Pending':
        return {
          bg: 'bg-amber-50 text-amber-800 border-amber-200',
          dotColor: 'bg-amber-500',
        };
      case 'danger':
      case 'Cancelled':
      case 'Occupied':
        return {
          bg: 'bg-rose-50 text-rose-800 border-rose-200',
          dotColor: 'bg-rose-500',
        };
      case 'info':
        return {
          bg: 'bg-sky-50 text-sky-800 border-sky-200',
          dotColor: 'bg-sky-500',
        };
      case 'neutral':
      default:
        return {
          bg: 'bg-slate-100 text-slate-700 border-slate-200',
          dotColor: 'bg-slate-400',
        };
    }
  };

  const { bg, dotColor } = getStyles();
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs font-semibold';

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border ${bg} ${sizeClasses} tracking-wide transition-colors`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dotColor}`} />}
      {children}
    </span>
  );
};
