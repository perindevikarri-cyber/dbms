import React, { useState } from 'react';
import { Modal } from './Modal';
import { dbOverviewService } from '../../services/dbOverviewService';
import { Database, Table, Key, Copy, Check } from 'lucide-react';

interface SchemaViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SchemaViewerModal: React.FC<SchemaViewerModalProps> = ({ isOpen, onClose }) => {
  const schemaList = dbOverviewService.getSchemaDetails();
  const [selectedTable, setSelectedTable] = useState(schemaList[0].tableName);
  const [copied, setCopied] = useState(false);

  const activeTable = schemaList.find((s) => s.tableName === selectedTable) || schemaList[0];

  const handleCopyDDL = () => {
    navigator.clipboard.writeText(activeTable.ddl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="MySQL 8.0 Database Architecture (Hospital_Management_System)"
      subtitle="Relational schema, Primary Keys, Foreign Key constraints & DDL definitions for college project submission."
      maxWidth="3xl"
    >
      <div className="space-y-5">
        {/* Table Selector Tabs */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl">
          {schemaList.map((t) => (
            <button
              key={t.tableName}
              onClick={() => setSelectedTable(t.tableName)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedTable === t.tableName
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.tableName}
            </button>
          ))}
        </div>

        {/* Selected Table Details */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3 pb-3 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <Table className="w-5 h-5 text-sky-700" />
              <div>
                <h4 className="text-sm font-bold text-slate-900">Table: {activeTable.tableName}</h4>
                <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500">
                  <span>PK: <code className="text-sky-800 font-mono font-semibold">{activeTable.primaryKey}</code></span>
                  {activeTable.foreignKeys.length > 0 && (
                    <span>• FKs: <code className="text-teal-700 font-mono font-semibold">{activeTable.foreignKeys.join(', ')}</code></span>
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={handleCopyDDL}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied SQL' : 'Copy DDL'}
            </button>
          </div>

          {/* Columns Table */}
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-2 px-3">Column Name</th>
                  <th className="py-2 px-3">Data Type</th>
                  <th className="py-2 px-3">Constraint / Key</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/60 font-mono">
                {activeTable.columns.map((col) => (
                  <tr key={col.name} className="hover:bg-slate-100/50">
                    <td className="py-2 px-3 font-semibold text-slate-900 flex items-center gap-1.5">
                      {col.key.includes('PRIMARY') && <Key className="w-3 h-3 text-amber-500 inline" />}
                      {col.name}
                    </td>
                    <td className="py-2 px-3 text-sky-700">{col.type}</td>
                    <td className="py-2 px-3 text-slate-600 font-sans text-[11px]">{col.key}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* MySQL DDL Code Snippet */}
          <div>
            <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Exact MySQL 8.0 DDL Statement
            </div>
            <pre className="p-3 bg-slate-900 text-teal-300 rounded-lg text-xs font-mono overflow-x-auto leading-relaxed">
              {activeTable.ddl}
            </pre>
          </div>
        </div>

        {/* Relational Mapping Note */}
        <div className="bg-sky-50 border border-sky-200 rounded-xl p-3.5 text-xs text-sky-950 flex items-start gap-2.5">
          <Database className="w-4 h-4 text-sky-700 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">DBMS Project Verification:</span> All foreign key constraints (`Patient_ID`, `Doctor_ID`) exactly mirror the college MySQL schema specifications. No synthetic tables or unrelated entities are present.
          </div>
        </div>
      </div>
    </Modal>
  );
};
