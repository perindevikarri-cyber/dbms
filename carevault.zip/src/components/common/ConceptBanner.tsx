import React from 'react';
import { FileText, Database, ArrowRight, Zap, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';

interface ConceptBannerProps {
  onQuickDemo?: () => void;
  compact?: boolean;
}

export const ConceptBanner: React.FC<ConceptBannerProps> = ({ onQuickDemo, compact = false }) => {
  if (compact) {
    return (
      <div className="bg-gradient-to-r from-teal-900 to-sky-950 text-white rounded-xl p-4 shadow-sm border border-teal-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-teal-500/20 text-teal-300 rounded-lg">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-300">College DBMS Project Core Concept</span>
            <p className="text-xs text-slate-200">
              Transforming physical file silos into centralized instant digital retrieval across 8 relational tables.
            </p>
          </div>
        </div>
        {onQuickDemo && (
          <button
            onClick={onQuickDemo}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold transition-all shadow-sm shrink-0 self-start sm:self-auto cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Test Rahul Kumar Flow
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-sky-950 to-teal-950 text-white rounded-2xl p-5 sm:p-6 shadow-sm border border-slate-800">
      {/* Decorative background grid */}
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]" />

      <div className="relative z-10">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4 pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-teal-500/20 text-teal-300 border border-teal-400/30">
              <ShieldCheck className="w-3.5 h-3.5" />
              DBMS Problem Statement & Solution
            </span>
            <span className="text-xs text-slate-300 font-medium">
              Hospital_Management_System (MySQL 8.0)
            </span>
          </div>

          {onQuickDemo && (
            <button
              onClick={onQuickDemo}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-teal-400 hover:bg-teal-300 text-slate-950 text-xs font-extrabold transition-all shadow-md hover:shadow-teal-400/20 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-slate-950" />
              Run Primary Demo: Rahul Kumar (ID #1)
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-11 gap-4 items-center">
          {/* Old System Box */}
          <div className="md:col-span-5 bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-2 text-rose-300 text-xs font-bold uppercase tracking-wider mb-2">
              <FileText className="w-4 h-4 text-rose-400" />
              Manual Paper System (Legacy)
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Medical records, prescriptions, test reports, and bills kept in disjoint physical paper folders.
            </p>
            <div className="mt-3 flex items-center gap-2 text-[11px] text-rose-200/80 bg-rose-950/40 px-2.5 py-1.5 rounded-md border border-rose-800/40">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 shrink-0" />
              Slow, prone to loss, zero relational indexing.
            </div>
          </div>

          {/* Transformation Arrow */}
          <div className="md:col-span-1 flex flex-col items-center justify-center text-teal-400">
            <div className="w-8 h-8 rounded-full bg-teal-500/20 border border-teal-400/40 flex items-center justify-center">
              <ArrowRight className="w-4 h-4" />
            </div>
            <span className="text-[10px] text-teal-300/80 font-bold uppercase tracking-widest mt-1">
              DIGITIZE
            </span>
          </div>

          {/* New System Box */}
          <div className="md:col-span-5 bg-teal-950/60 border border-teal-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 text-teal-300 text-xs font-bold uppercase tracking-wider mb-2">
              <Database className="w-4 h-4 text-teal-400" />
              Proposed CAREVAULT Digital System
            </div>
            <p className="text-xs text-slate-200 leading-relaxed">
              One search by <span className="text-white font-semibold underline decoration-teal-400">Patient Name or ID</span> retrieves all connected records across 8 relational tables.
            </p>
            <div className="mt-3 flex items-center gap-2 text-[11px] text-teal-200 bg-teal-900/40 px-2.5 py-1.5 rounded-md border border-teal-700/40">
              <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0" />
              Patient + Appointments + Records + Rx + Labs + Billing in 1 click.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
