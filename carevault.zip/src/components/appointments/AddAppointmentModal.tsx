import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { appointmentService } from '../../services/appointmentService';
import { patientService } from '../../services/patientService';
import { doctorService } from '../../services/doctorService';
import { Appointment } from '../../types/database';

interface AddAppointmentModalProps {
  isOpen: boolean;
  preselectedPatientId?: number | null;
  onClose: () => void;
  onSuccess: (newAppt: Appointment) => void;
}

export const AddAppointmentModal: React.FC<AddAppointmentModalProps> = ({
  isOpen,
  preselectedPatientId,
  onClose,
  onSuccess,
}) => {
  const patients = patientService.getAll();
  const doctors = doctorService.getAll();

  const [formData, setFormData] = useState({
    Patient_ID: preselectedPatientId || (patients[0]?.Patient_ID ?? 1),
    Doctor_ID: doctors[0]?.Doctor_ID ?? 1,
    Appointment_Date: new Date().toISOString().split('T')[0],
    Appointment_Time: '10:00 AM',
    Status: 'Scheduled' as Appointment['Status'],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const created = appointmentService.create({
      Patient_ID: Number(formData.Patient_ID),
      Doctor_ID: Number(formData.Doctor_ID),
      Appointment_Date: formData.Appointment_Date,
      Appointment_Time: formData.Appointment_Time,
      Status: formData.Status,
    });
    onSuccess(created);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Schedule New Appointment"
      subtitle="Inserts record into MySQL Appointment table linking Patient and Doctor"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Patient *
          </label>
          <select
            value={formData.Patient_ID}
            onChange={(e) => setFormData({ ...formData, Patient_ID: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            {patients.map((p) => (
              <option key={p.Patient_ID} value={p.Patient_ID}>
                {p.Name} (ID: #{p.Patient_ID}) — {p.Blood_Group}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Doctor *
          </label>
          <select
            value={formData.Doctor_ID}
            onChange={(e) => setFormData({ ...formData, Doctor_ID: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            {doctors.map((d) => (
              <option key={d.Doctor_ID} value={d.Doctor_ID}>
                {d.Name} — {d.Department} ({d.Specialization})
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Date *
            </label>
            <input
              type="date"
              value={formData.Appointment_Date}
              onChange={(e) => setFormData({ ...formData, Appointment_Date: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Time Slot *
            </label>
            <select
              value={formData.Appointment_Time}
              onChange={(e) => setFormData({ ...formData, Appointment_Time: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
            >
              <option value="09:00 AM">09:00 AM</option>
              <option value="09:30 AM">09:30 AM</option>
              <option value="10:00 AM">10:00 AM</option>
              <option value="10:30 AM">10:30 AM</option>
              <option value="11:00 AM">11:00 AM</option>
              <option value="11:30 AM">11:30 AM</option>
              <option value="02:00 PM">02:00 PM</option>
              <option value="02:30 PM">02:30 PM</option>
              <option value="03:00 PM">03:00 PM</option>
              <option value="03:30 PM">03:30 PM</option>
              <option value="04:00 PM">04:00 PM</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Status *
          </label>
          <select
            value={formData.Status}
            onChange={(e) =>
              setFormData({ ...formData, Status: e.target.value as Appointment['Status'] })
            }
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            <option value="Scheduled">Scheduled</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs cursor-pointer"
          >
            Save Appointment
          </button>
        </div>
      </form>
    </Modal>
  );
};
