import React, { useState, useMemo } from 'react';
import { Plus, Filter, Calendar as CalendarIcon, UserCheck, Clock, Check, X, Search } from 'lucide-react';
import { appointmentService } from '../../services/appointmentService';
import { doctorService } from '../../services/doctorService';
import { JoinedAppointment, Appointment } from '../../types/database';
import { Badge } from '../common/Badge';

interface AppointmentsViewProps {
  onSelectPatient: (patientId: number) => void;
  onOpenAddModal: () => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const AppointmentsView: React.FC<AppointmentsViewProps> = ({
  onSelectPatient,
  onOpenAddModal,
  onNotify,
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [doctorFilter, setDoctorFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const appointments = appointmentService.getAllJoined();
  const doctors = doctorService.getAll();

  const filteredAppointments = useMemo(() => {
    return appointments.filter((appt) => {
      const matchStatus = statusFilter === 'All' || appt.Status === statusFilter;
      const matchDoctor = doctorFilter === 'All' || appt.Doctor_ID === Number(doctorFilter);
      const matchSearch =
        !searchQuery ||
        appt.patient?.Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        appt.doctor?.Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        appt.doctor?.Department.toLowerCase().includes(searchQuery.toLowerCase());

      return matchStatus && matchDoctor && matchSearch;
    });
  }, [appointments, statusFilter, doctorFilter, searchQuery]);

  const handleUpdateStatus = (id: number, newStatus: Appointment['Status']) => {
    appointmentService.updateStatus(id, newStatus);
    onNotify('success', `Appointment #${id} updated to ${newStatus}.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            Appointments
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
              {appointments.length} Total Records
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Appointment scheduling table with Foreign Keys to Patient and Doctor.
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          + New Appointment
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search patient, doctor, or department..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          {/* Status filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-700 focus:outline-hidden"
            >
              <option value="All">All Statuses</option>
              <option value="Scheduled">Scheduled</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          {/* Doctor filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Doctor:</span>
            <select
              value={doctorFilter}
              onChange={(e) => setDoctorFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-700 focus:outline-hidden"
            >
              <option value="All">All Doctors</option>
              {doctors.map((d) => (
                <option key={d.Doctor_ID} value={d.Doctor_ID}>
                  {d.Name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Appointments Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Appointments Table (MySQL <code className="text-teal-700 font-mono">Appointment</code>)
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredAppointments.length} of {appointments.length}
          </span>
        </div>

        {filteredAppointments.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider bg-slate-50/60">
                  <th className="py-3 px-4">Appt ID</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Doctor</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Time</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAppointments.map((appt) => (
                  <tr key={appt.Appointment_ID} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-600">
                      #{appt.Appointment_ID}
                    </td>
                    <td className="py-3.5 px-4">
                      <button
                        onClick={() => onSelectPatient(appt.Patient_ID)}
                        className="font-bold text-slate-900 hover:text-teal-700 text-left cursor-pointer hover:underline"
                      >
                        {appt.patient?.Name || `Patient #${appt.Patient_ID}`}
                      </button>
                      <div className="text-[11px] text-slate-400">ID: P{String(appt.Patient_ID).padStart(3, '0')}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800">{appt.doctor?.Name || `Dr. #${appt.Doctor_ID}`}</div>
                      <div className="text-[11px] text-slate-500">{appt.doctor?.Specialization}</div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">{appt.doctor?.Department}</td>
                    <td className="py-3.5 px-4 font-medium text-slate-800">{appt.Appointment_Date}</td>
                    <td className="py-3.5 px-4 font-mono text-slate-600">{appt.Appointment_Time}</td>
                    <td className="py-3.5 px-4">
                      <Badge variant={appt.Status} dot size="sm">
                        {appt.Status}
                      </Badge>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      {appt.Status === 'Scheduled' && (
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => handleUpdateStatus(appt.Appointment_ID, 'Completed')}
                            title="Mark as Completed"
                            className="p-1 text-emerald-700 hover:bg-emerald-100 rounded-md transition-colors cursor-pointer"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(appt.Appointment_ID, 'Cancelled')}
                            title="Cancel Appointment"
                            className="p-1 text-rose-600 hover:bg-rose-100 rounded-md transition-colors cursor-pointer"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-xs text-slate-400">
            No appointments match the selected filters.
          </div>
        )}
      </div>
    </div>
  );
};
