import React from 'react';
import { Database, RotateCcw, ShieldCheck, Download, Code, CheckCircle2 } from 'lucide-react';
import { storage } from '../../services/storage';

interface SettingsViewProps {
  onOpenSchema: () => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
  onRefresh: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  onOpenSchema,
  onNotify,
  onRefresh,
}) => {
  const handleResetData = () => {
    if (window.confirm('Reset all hospital records back to the default MySQL 8.0 seed dataset?')) {
      storage.resetToDefault();
      onRefresh();
      onNotify('success', 'Hospital database reset to initial demo state successfully.');
    }
  };

  const handleExportData = () => {
    const backup = {
      patients: storage.getPatients(),
      doctors: storage.getDoctors(),
      appointments: storage.getAppointments(),
      rooms: storage.getRooms(),
      medicalRecords: storage.getMedicalRecords(),
      prescriptions: storage.getPrescriptions(),
      laboratoryTests: storage.getLaboratoryTests(),
      billing: storage.getBilling(),
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `carevault_db_dump_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('info', 'Database state exported as JSON file.');
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
          System Settings & Database Architecture
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          CAREVAULT College DBMS Project Configuration & Storage Management.
        </p>
      </div>

      {/* Database Schema Card */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-teal-50 text-teal-700 rounded-xl">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Target Database: Hospital_Management_System
              </h3>
              <p className="text-xs text-slate-500">
                MySQL 8.0 Relational Engine • 8 Dedicated Tables
              </p>
            </div>
          </div>

          <button
            onClick={onOpenSchema}
            className="px-3.5 py-1.5 bg-sky-50 text-sky-800 hover:bg-sky-100 border border-sky-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            Inspect Schema & DDL
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          {[
            { name: 'Patient', count: storage.getPatients().length, pk: 'Patient_ID' },
            { name: 'Doctor', count: storage.getDoctors().length, pk: 'Doctor_ID' },
            { name: 'Appointment', count: storage.getAppointments().length, pk: 'Appointment_ID' },
            { name: 'Room', count: storage.getRooms().length, pk: 'Room_ID' },
            { name: 'Medical_Record', count: storage.getMedicalRecords().length, pk: 'Record_ID' },
            { name: 'Prescription', count: storage.getPrescriptions().length, pk: 'Prescription_ID' },
            { name: 'Laboratory_Test', count: storage.getLaboratoryTests().length, pk: 'Test_ID' },
            { name: 'Billing', count: storage.getBilling().length, pk: 'Bill_ID' },
          ].map((table) => (
            <div key={table.name} className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <span className="font-bold text-slate-900 font-mono">{table.name}</span>
              <div className="flex items-center justify-between mt-1 text-[11px] text-slate-500">
                <span>PK: {table.pk}</span>
                <span className="font-semibold text-teal-700">{table.count} rows</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Demo Reset and Controls */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900">Prototype Demonstration State</h3>
        <p className="text-xs text-slate-500 leading-relaxed">
          The prototype maintains browser storage with the original 10 patients, 5 doctors, appointments, medical records, prescriptions, laboratory reports, and billing ledger.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleResetData}
            className="inline-flex items-center gap-2 px-4 py-2 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            Reset to Default Seed Data
          </button>

          <button
            onClick={handleExportData}
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Export State (JSON)
          </button>
        </div>
      </div>

      {/* Project Notes */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-sm border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 text-teal-400 font-bold text-xs uppercase tracking-wider">
          <ShieldCheck className="w-4 h-4" />
          Academic DBMS Evaluation Notes
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          <strong>Key Demonstration:</strong> Demonstrates migration from paper file systems to indexed digital retrieval. When searching for patient <strong>Rahul Kumar (ID #1)</strong>, relational foreign key joins fetch the exact appointment with Dr. Anil Kumar, diagnosis for hypertension/gastritis, prescription for Amlodipine, laboratory ECG/lipid profile, and ₹4,500 settled billing record.
        </p>
      </div>
    </div>
  );
};
