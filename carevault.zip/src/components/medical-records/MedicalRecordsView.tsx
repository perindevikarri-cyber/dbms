import React, { useState } from 'react';
import { Plus, Search, FileHeart, Calendar, ChevronRight } from 'lucide-react';
import { medicalRecordService } from '../../services/medicalRecordService';

interface MedicalRecordsViewProps {
  onSelectPatient: (patientId: number) => void;
  onOpenAddModal: () => void;
}

export const MedicalRecordsView: React.FC<MedicalRecordsViewProps> = ({
  onSelectPatient,
  onOpenAddModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const records = medicalRecordService.getAllJoined();

  const filtered = records.filter(
    (r) =>
      r.Diagnosis.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.Treatment.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.patient?.Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(r.Record_ID).includes(searchQuery)
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            Medical Records
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
              {records.length} Stored Records
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Diagnosis, treatment, and inpatient admission timeline from Medical_Record table.
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          + Add Medical Record
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-xs">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search records by diagnosis, treatment, patient name, or record ID..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Records Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Medical Records Table (MySQL <code className="text-teal-700 font-mono">Medical_Record</code>)
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filtered.length} of {records.length}
          </span>
        </div>

        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider bg-slate-50/60">
                  <th className="py-3 px-4">Record ID</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Diagnosis</th>
                  <th className="py-3 px-4">Treatment</th>
                  <th className="py-3 px-4">Admission</th>
                  <th className="py-3 px-4">Discharge</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((r) => (
                  <tr key={r.Record_ID} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-600">#{r.Record_ID}</td>
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      <button
                        onClick={() => onSelectPatient(r.Patient_ID)}
                        className="hover:text-teal-700 hover:underline cursor-pointer text-left"
                      >
                        {r.patient?.Name || `Patient #${r.Patient_ID}`}
                      </button>
                      <div className="text-[11px] text-slate-400">ID: #{r.Patient_ID}</div>
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900">{r.Diagnosis}</td>
                    <td className="py-3.5 px-4 text-slate-600 max-w-xs">{r.Treatment}</td>
                    <td className="py-3.5 px-4 font-mono text-slate-700">{r.Admission_Date}</td>
                    <td className="py-3.5 px-4 font-mono text-slate-700">{r.Discharge_Date}</td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => onSelectPatient(r.Patient_ID)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-600 hover:text-white rounded-lg border border-teal-200 transition-colors cursor-pointer"
                      >
                        Patient Profile
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-xs text-slate-400">
            No medical records match your query.
          </div>
        )}
      </div>
    </div>
  );
};
