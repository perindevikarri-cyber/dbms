import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { medicalRecordService } from '../../services/medicalRecordService';
import { patientService } from '../../services/patientService';
import { MedicalRecord } from '../../types/database';

interface AddMedicalRecordModalProps {
  isOpen: boolean;
  preselectedPatientId?: number | null;
  onClose: () => void;
  onSuccess: (record: MedicalRecord) => void;
}

export const AddMedicalRecordModal: React.FC<AddMedicalRecordModalProps> = ({
  isOpen,
  preselectedPatientId,
  onClose,
  onSuccess,
}) => {
  const patients = patientService.getAll();

  const [formData, setFormData] = useState({
    Patient_ID: preselectedPatientId || (patients[0]?.Patient_ID ?? 1),
    Diagnosis: '',
    Treatment: '',
    Admission_Date: new Date().toISOString().split('T')[0],
    Discharge_Date: new Date().toISOString().split('T')[0],
  });

  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.Diagnosis.trim() || !formData.Treatment.trim()) {
      setError('Diagnosis and Treatment are both required.');
      return;
    }

    const created = medicalRecordService.create({
      Patient_ID: Number(formData.Patient_ID),
      Diagnosis: formData.Diagnosis.trim(),
      Treatment: formData.Treatment.trim(),
      Admission_Date: formData.Admission_Date,
      Discharge_Date: formData.Discharge_Date,
    });

    onSuccess(created);
    onClose();
    setFormData({
      Patient_ID: patients[0]?.Patient_ID ?? 1,
      Diagnosis: '',
      Treatment: '',
      Admission_Date: new Date().toISOString().split('T')[0],
      Discharge_Date: new Date().toISOString().split('T')[0],
    });
    setError('');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Add Medical Record"
      subtitle="Creates clinical record in MySQL Medical_Record table"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="p-2.5 rounded-lg bg-rose-50 text-rose-700 text-xs font-semibold">{error}</div>}

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Patient *
          </label>
          <select
            value={formData.Patient_ID}
            onChange={(e) => setFormData({ ...formData, Patient_ID: Number(e.target.value) })}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500 bg-white"
          >
            {patients.map((p) => (
              <option key={p.Patient_ID} value={p.Patient_ID}>
                {p.Name} (ID: #{p.Patient_ID}) — {p.Blood_Group}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Diagnosis *
          </label>
          <input
            type="text"
            value={formData.Diagnosis}
            onChange={(e) => setFormData({ ...formData, Diagnosis: e.target.value })}
            placeholder="e.g. Mild Hypertension & Acute Gastritis"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
            Treatment / Clinical Plan *
          </label>
          <textarea
            rows={3}
            value={formData.Treatment}
            onChange={(e) => setFormData({ ...formData, Treatment: e.target.value })}
            placeholder="e.g. Antacids, lifestyle modification, hydration, and follow-up in 2 weeks"
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Admission Date *
            </label>
            <input
              type="date"
              value={formData.Admission_Date}
              onChange={(e) => setFormData({ ...formData, Admission_Date: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Discharge Date *
            </label>
            <input
              type="date"
              value={formData.Discharge_Date}
              onChange={(e) => setFormData({ ...formData, Discharge_Date: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-teal-500"
            />
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs cursor-pointer"
          >
            Save Medical Record
          </button>
        </div>
      </form>
    </Modal>
  );
};
