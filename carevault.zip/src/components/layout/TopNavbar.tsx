import React, { useState, useRef, useEffect } from 'react';
import { Search, Bell, User, Sparkles, Database, X, ChevronRight, Menu } from 'lucide-react';
import { patientService } from '../../services/patientService';
import { Patient } from '../../types/database';

interface TopNavbarProps {
  onSelectPatient: (patientId: number) => void;
  onOpenSchema: () => void;
  onToggleSidebar?: () => void;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  onSelectPatient,
  onOpenSchema,
  onToggleSidebar,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Patient[]>([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);

  // Notifications demo list
  const notifications = [
    { id: 1, title: 'Lab Test Recorded', time: '10m ago', text: 'Lipid Profile & ECG result filed for Rahul Kumar' },
    { id: 2, title: 'Appointment Scheduled', time: '45m ago', text: 'Dr. Anil Kumar with Rahul Kumar at 09:30 AM' },
    { id: 3, title: 'Room Status Update', time: '2h ago', text: 'ICU Room I302 marked as Occupied' },
  ];

  useEffect(() => {
    if (searchQuery.trim().length > 0) {
      const results = patientService.search(searchQuery);
      setSearchResults(results.slice(0, 6));
      setIsDropdownOpen(true);
    } else {
      setSearchResults([]);
      setIsDropdownOpen(false);
    }
  }, [searchQuery]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
      if (notificationsRef.current && !notificationsRef.current.contains(e.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (patientId: number) => {
    onSelectPatient(patientId);
    setIsDropdownOpen(false);
    setSearchQuery('');
  };

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 py-3 transition-all">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile hamburger & Search input */}
        <div className="flex items-center gap-3 flex-1 max-w-2xl">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
              aria-label="Toggle navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          {/* Global Search Bar */}
          <div ref={searchContainerRef} className="relative w-full">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => {
                  if (searchQuery.trim().length > 0) setIsDropdownOpen(true);
                }}
                placeholder="Global search: Type patient name (e.g. Rahul Kumar) or Patient ID (e.g. 1)..."
                className="w-full pl-10 pr-9 py-2 bg-slate-100/80 hover:bg-slate-100 focus:bg-white border border-slate-200 focus:border-teal-500 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded-full"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Instant Search Results Dropdown */}
            {isDropdownOpen && (
              <div className="absolute left-0 right-0 top-full mt-1.5 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                <div className="px-3.5 py-2 bg-slate-50 border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                  <span>Patient Search Results</span>
                  <span>{searchResults.length} found</span>
                </div>

                {searchResults.length > 0 ? (
                  <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                    {searchResults.map((p) => (
                      <div
                        key={p.Patient_ID}
                        onClick={() => handleSelect(p.Patient_ID)}
                        className="p-3 hover:bg-teal-50/60 cursor-pointer flex items-center justify-between transition-colors group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-800 font-bold text-xs flex items-center justify-center shrink-0">
                            {p.Name.charAt(0)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-semibold text-slate-900 group-hover:text-teal-700">
                                {p.Name}
                              </span>
                              <span className="text-[11px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-mono">
                                ID: {p.Patient_ID}
                              </span>
                              <span className="text-[11px] px-1.5 py-0.2 rounded bg-rose-50 text-rose-700 font-semibold">
                                {p.Blood_Group}
                              </span>
                            </div>
                            <div className="text-xs text-slate-500 mt-0.5">
                              {p.Age} yrs • {p.Gender} • {p.Address} • {p.Phone_Number}
                            </div>
                          </div>
                        </div>

                        <span className="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-200/60 group-hover:bg-teal-600 group-hover:text-white transition-all shrink-0">
                          Open Record
                          <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No patient record found matching &quot;{searchQuery}&quot;. Try searching &quot;Rahul Kumar&quot; or &quot;1&quot;.
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right action controls */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Quick Demo Button for Rahul Kumar */}
          <button
            onClick={() => onSelectPatient(1)}
            title="Open primary demonstration patient: Rahul Kumar (ID #1)"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-50 hover:bg-teal-100/80 text-teal-800 text-xs font-bold border border-teal-200 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-600" />
            <span>Demo: Rahul Kumar</span>
          </button>

          {/* Relational Schema button */}
          <button
            onClick={onOpenSchema}
            title="Inspect MySQL 8.0 Schema and Foreign Keys"
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
          >
            <Database className="w-3.5 h-3.5 text-sky-600" />
            <span className="hidden md:inline">Schema (MySQL)</span>
          </button>

          {/* Notifications Dropdown */}
          <div ref={notificationsRef} className="relative">
            <button
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-teal-600 ring-2 ring-white" />
            </button>

            {isNotificationsOpen && (
              <div className="absolute right-0 top-full mt-2 w-80 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden z-50">
                <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Hospital Activity
                  </span>
                  <span className="text-[10px] text-teal-700 font-medium">3 recent</span>
                </div>
                <div className="divide-y divide-slate-100">
                  {notifications.map((n) => (
                    <div key={n.id} className="p-3 hover:bg-slate-50 transition-colors text-xs">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-slate-900">{n.title}</span>
                        <span className="text-[10px] text-slate-400">{n.time}</span>
                      </div>
                      <p className="text-slate-600 text-[11px] leading-snug">{n.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Profile */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-800 flex items-center justify-center font-bold text-xs">
              <User className="w-4 h-4" />
            </div>
            <div className="hidden xl:flex flex-col text-left">
              <span className="text-xs font-bold text-slate-900 leading-none">Admin Desk</span>
              <span className="text-[10px] text-slate-500 font-medium leading-none mt-0.5">Records Dept</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
