import React from 'react';
import { CarevaultLogo } from '../common/CarevaultLogo';
import {
  LayoutDashboard,
  Users,
  UserCheck,
  Calendar,
  FileHeart,
  Pill,
  FlaskConical,
  Receipt,
  BedDouble,
  Settings,
  Database,
  ExternalLink,
  X,
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'patients'
  | 'doctors'
  | 'appointments'
  | 'medical-records'
  | 'prescriptions'
  | 'laboratory'
  | 'billing'
  | 'rooms'
  | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isOpen: boolean;
  onClose?: () => void;
  onOpenSchema: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpen,
  onClose,
  onOpenSchema,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'patients', label: 'Patients', icon: Users, badge: 'Main' },
    { id: 'doctors', label: 'Doctors', icon: UserCheck },
    { id: 'appointments', label: 'Appointments', icon: Calendar },
    { id: 'medical-records', label: 'Medical Records', icon: FileHeart },
    { id: 'prescriptions', label: 'Prescriptions', icon: Pill },
    { id: 'laboratory', label: 'Laboratory', icon: FlaskConical },
    { id: 'billing', label: 'Billing', icon: Receipt },
    { id: 'rooms', label: 'Rooms', icon: BedDouble },
  ] as const;

  const handleNavClick = (tab: NavTab) => {
    onSelectTab(tab);
    if (onClose) onClose();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-slate-900 text-slate-200 flex flex-col border-r border-slate-800 transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header Branding */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <CarevaultLogo
            size="md"
            showText={true}
            className="[&_span.text-slate-900]:text-white [&_span.text-slate-500]:text-slate-400 [&_span.bg-teal-50]:bg-teal-950 [&_span.bg-teal-50]:text-teal-400 [&_span.border-teal-200]:border-teal-800"
          />
          {onClose && (
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation Section */}
        <div className="flex-1 px-3 py-4 overflow-y-auto space-y-1">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Hospital System (8 Tables)
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-teal-600 text-white shadow-md shadow-teal-900/30'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-white' : 'text-slate-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                {'badge' in item && item.badge && !isActive && (
                  <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-teal-500/20 text-teal-300">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom Section */}
        <div className="p-3 border-t border-slate-800 space-y-2">
          {/* Quick MySQL Schema Explorer Button */}
          <button
            onClick={() => {
              onOpenSchema();
              if (onClose) onClose();
            }}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Database className="w-4 h-4 text-teal-400" />
              <span>MySQL 8.0 DDL Schema</span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
          </button>

          {/* Settings tab */}
          <button
            onClick={() => handleNavClick('settings')}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              currentTab === 'settings'
                ? 'bg-slate-800 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Settings className="w-4 h-4 text-slate-400" />
            <span>Settings & Data Config</span>
          </button>

          {/* Database connection badge */}
          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-[10px] text-slate-300">MySQL 8.0 Model</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">DBMS Proj</span>
          </div>
        </div>
      </aside>
    </>
  );
};
