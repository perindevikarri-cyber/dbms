import React, { useState, useCallback } from 'react';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { TopNavbar } from './components/layout/TopNavbar';
import { DashboardView } from './components/dashboard/DashboardView';
import { PatientsView } from './components/patients/PatientsView';
import { PatientProfileView } from './components/patients/PatientProfileView';
import { DoctorsView } from './components/doctors/DoctorsView';
import { AppointmentsView } from './components/appointments/AppointmentsView';
import { MedicalRecordsView } from './components/medical-records/MedicalRecordsView';
import { PrescriptionsView } from './components/prescriptions/PrescriptionsView';
import { LaboratoryView } from './components/laboratory/LaboratoryView';
import { BillingView } from './components/billing/BillingView';
import { RoomsView } from './components/rooms/RoomsView';
import { SettingsView } from './components/settings/SettingsView';

import { AddPatientModal } from './components/patients/AddPatientModal';
import { EditPatientModal } from './components/patients/EditPatientModal';
import { AddAppointmentModal } from './components/appointments/AddAppointmentModal';
import { AddMedicalRecordModal } from './components/medical-records/AddMedicalRecordModal';
import { AddPrescriptionModal } from './components/prescriptions/AddPrescriptionModal';
import { AddLabTestModal } from './components/laboratory/AddLabTestModal';
import { CreateBillModal } from './components/billing/CreateBillModal';
import { SchemaViewerModal } from './components/common/SchemaViewerModal';
import { ToastContainer, ToastMessage } from './components/common/Toast';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [selectedPatientId, setSelectedPatientId] = useState<number | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Modals state
  const [isAddPatientOpen, setIsAddPatientOpen] = useState(false);
  const [editPatientId, setEditPatientId] = useState<number | null>(null);
  const [addApptPatientId, setAddApptPatientId] = useState<number | null>(null);
  const [isAddApptOpen, setIsAddApptOpen] = useState(false);
  const [addRecordPatientId, setAddRecordPatientId] = useState<number | null>(null);
  const [isAddRecordOpen, setIsAddRecordOpen] = useState(false);
  const [addPrescriptionPatientId, setAddPrescriptionPatientId] = useState<number | null>(null);
  const [isAddPrescriptionOpen, setIsAddPrescriptionOpen] = useState(false);
  const [addLabTestPatientId, setAddLabTestPatientId] = useState<number | null>(null);
  const [isAddLabTestOpen, setIsAddLabTestOpen] = useState(false);
  const [addBillPatientId, setAddBillPatientId] = useState<number | null>(null);
  const [isAddBillOpen, setIsAddBillOpen] = useState(false);
  const [isSchemaModalOpen, setIsSchemaModalOpen] = useState(false);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((type: 'success' | 'error' | 'info', message: string) => {
    const id = `${Date.now()}_${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, message }]);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const handleSelectPatient = (patientId: number) => {
    setSelectedPatientId(patientId);
  };

  const handleSelectTab = (tab: NavTab) => {
    setCurrentTab(tab);
    setSelectedPatientId(null);
  };

  const triggerGlobalRefresh = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-teal-100 selection:text-teal-900">
      {/* Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Left Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onOpenSchema={() => setIsSchemaModalOpen(true)}
      />

      {/* Main Content Layout */}
      <div className="lg:pl-64 flex flex-col flex-1 min-h-screen transition-all">
        {/* Top Navbar */}
        <TopNavbar
          onSelectPatient={handleSelectPatient}
          onOpenSchema={() => setIsSchemaModalOpen(true)}
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        />

        {/* Page Content View */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {selectedPatientId !== null ? (
            <PatientProfileView
              key={`profile_${selectedPatientId}_${refreshTrigger}`}
              patientId={selectedPatientId}
              onBack={() => setSelectedPatientId(null)}
              onEditPatient={(id) => setEditPatientId(id)}
              onAddAppointment={(id) => {
                setAddApptPatientId(id);
                setIsAddApptOpen(true);
              }}
              onAddRecord={(id) => {
                setAddRecordPatientId(id);
                setIsAddRecordOpen(true);
              }}
              onAddPrescription={(id) => {
                setAddPrescriptionPatientId(id);
                setIsAddPrescriptionOpen(true);
              }}
              onAddLabTest={(id) => {
                setAddLabTestPatientId(id);
                setIsAddLabTestOpen(true);
              }}
              onAddBill={(id) => {
                setAddBillPatientId(id);
                setIsAddBillOpen(true);
              }}
              onNotify={addToast}
            />
          ) : (
            <>
              {currentTab === 'dashboard' && (
                <DashboardView
                  key={`dash_${refreshTrigger}`}
                  onSelectPatient={handleSelectPatient}
                  onNavigateTab={handleSelectTab}
                  onOpenSchema={() => setIsSchemaModalOpen(true)}
                  onNotify={addToast}
                />
              )}

              {currentTab === 'patients' && (
                <PatientsView
                  key={`patients_${refreshTrigger}`}
                  onViewRecord={handleSelectPatient}
                  onOpenAddModal={() => setIsAddPatientOpen(true)}
                  onNotify={addToast}
                />
              )}

              {currentTab === 'doctors' && <DoctorsView key={`docs_${refreshTrigger}`} />}

              {currentTab === 'appointments' && (
                <AppointmentsView
                  key={`appts_${refreshTrigger}`}
                  onSelectPatient={handleSelectPatient}
                  onOpenAddModal={() => {
                    setAddApptPatientId(null);
                    setIsAddApptOpen(true);
                  }}
                  onNotify={addToast}
                />
              )}

              {currentTab === 'medical-records' && (
                <MedicalRecordsView
                  key={`med_records_${refreshTrigger}`}
                  onSelectPatient={handleSelectPatient}
                  onOpenAddModal={() => {
                    setAddRecordPatientId(null);
                    setIsAddRecordOpen(true);
                  }}
                />
              )}

              {currentTab === 'prescriptions' && (
                <PrescriptionsView
                  key={`rx_${refreshTrigger}`}
                  onSelectPatient={handleSelectPatient}
                  onOpenAddModal={() => {
                    setAddPrescriptionPatientId(null);
                    setIsAddPrescriptionOpen(true);
                  }}
                />
              )}

              {currentTab === 'laboratory' && (
                <LaboratoryView
                  key={`labs_${refreshTrigger}`}
                  onSelectPatient={handleSelectPatient}
                  onOpenAddModal={() => {
                    setAddLabTestPatientId(null);
                    setIsAddLabTestOpen(true);
                  }}
                />
              )}

              {currentTab === 'billing' && (
                <BillingView
                  key={`billing_${refreshTrigger}`}
                  onSelectPatient={handleSelectPatient}
                  onOpenCreateBill={() => {
                    setAddBillPatientId(null);
                    setIsAddBillOpen(true);
                  }}
                  onNotify={addToast}
                />
              )}

              {currentTab === 'rooms' && (
                <RoomsView key={`rooms_${refreshTrigger}`} onNotify={addToast} />
              )}

              {currentTab === 'settings' && (
                <SettingsView
                  key={`settings_${refreshTrigger}`}
                  onOpenSchema={() => setIsSchemaModalOpen(true)}
                  onNotify={addToast}
                  onRefresh={triggerGlobalRefresh}
                />
              )}
            </>
          )}
        </main>

        {/* Academic Project Footer */}
        <footer className="mt-auto border-t border-slate-200/80 bg-white/60 py-3.5 px-6 text-center text-xs text-slate-500">
          <div className="flex flex-wrap items-center justify-between gap-2 max-w-7xl mx-auto">
            <span>
              <strong>CAREVAULT</strong> — Digital Hospital Record Management System
            </span>
            <span className="font-mono text-[11px] text-slate-400">
              DBMS College Project • MySQL 8.0 Target Architecture (8 Tables)
            </span>
          </div>
        </footer>
      </div>

      {/* Global Modals */}
      {/* 1. Add Patient Modal */}
      <AddPatientModal
        isOpen={isAddPatientOpen}
        onClose={() => setIsAddPatientOpen(false)}
        onSuccess={(newPatient) => {
          addToast('success', `Patient record created successfully for ${newPatient.Name} (ID #${newPatient.Patient_ID}).`);
          triggerGlobalRefresh();
          setSelectedPatientId(newPatient.Patient_ID);
        }}
      />

      {/* 2. Edit Patient Modal */}
      <EditPatientModal
        isOpen={editPatientId !== null}
        patientId={editPatientId}
        onClose={() => setEditPatientId(null)}
        onSuccess={(updated) => {
          addToast('success', `Patient ${updated.Name} details saved successfully.`);
          triggerGlobalRefresh();
        }}
      />

      {/* 3. Add Appointment Modal */}
      <AddAppointmentModal
        isOpen={isAddApptOpen}
        preselectedPatientId={addApptPatientId}
        onClose={() => {
          setIsAddApptOpen(false);
          setAddApptPatientId(null);
        }}
        onSuccess={() => {
          addToast('success', 'Appointment scheduled successfully.');
          triggerGlobalRefresh();
        }}
      />

      {/* 4. Add Medical Record Modal */}
      <AddMedicalRecordModal
        isOpen={isAddRecordOpen}
        preselectedPatientId={addRecordPatientId}
        onClose={() => {
          setIsAddRecordOpen(false);
          setAddRecordPatientId(null);
        }}
        onSuccess={() => {
          addToast('success', 'Medical record logged successfully.');
          triggerGlobalRefresh();
        }}
      />

      {/* 5. Add Prescription Modal */}
      <AddPrescriptionModal
        isOpen={isAddPrescriptionOpen}
        preselectedPatientId={addPrescriptionPatientId}
        onClose={() => {
          setIsAddPrescriptionOpen(false);
          setAddPrescriptionPatientId(null);
        }}
        onSuccess={() => {
          addToast('success', 'Prescription added successfully.');
          triggerGlobalRefresh();
        }}
      />

      {/* 6. Add Laboratory Test Modal */}
      <AddLabTestModal
        isOpen={isAddLabTestOpen}
        preselectedPatientId={addLabTestPatientId}
        onClose={() => {
          setIsAddLabTestOpen(false);
          setAddLabTestPatientId(null);
        }}
        onSuccess={() => {
          addToast('success', 'Laboratory test result recorded successfully.');
          triggerGlobalRefresh();
        }}
      />

      {/* 7. Create Bill Modal */}
      <CreateBillModal
        isOpen={isAddBillOpen}
        preselectedPatientId={addBillPatientId}
        onClose={() => {
          setIsAddBillOpen(false);
          setAddBillPatientId(null);
        }}
        onSuccess={() => {
          addToast('success', 'Hospital bill generated successfully.');
          triggerGlobalRefresh();
        }}
      />

      {/* 8. MySQL Schema Viewer Modal */}
      <SchemaViewerModal
        isOpen={isSchemaModalOpen}
        onClose={() => setIsSchemaModalOpen(false)}
      />
    </div>
  );
}
