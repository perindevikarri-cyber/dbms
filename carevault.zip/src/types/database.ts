/**
 * CAREVAULT - Digital Hospital Record Management System
 * Database Schema Interfaces
 * 
 * Target Database: MySQL 8.0 (Hospital_Management_System)
 * 8 Tables:
 * 1. Patient
 * 2. Doctor
 * 3. Appointment
 * 4. Room
 * 5. Medical_Record
 * 6. Prescription
 * 7. Laboratory_Test
 * 8. Billing
 */

export interface Patient {
  Patient_ID: number;
  Name: string;
  Age: number;
  Gender: 'Male' | 'Female' | 'Other';
  Phone_Number: string;
  Address: string;
  Blood_Group: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
}

export interface Doctor {
  Doctor_ID: number;
  Name: string;
  Department: string;
  Specialization: string;
  Qualification: string;
  Phone_Number: string;
}

export interface Appointment {
  Appointment_ID: number;
  Patient_ID: number;
  Doctor_ID: number;
  Appointment_Date: string; // YYYY-MM-DD
  Appointment_Time: string; // HH:MM AM/PM
  Status: 'Scheduled' | 'Completed' | 'Cancelled';
}

export interface Room {
  Room_ID: string; // e.g. G101, P201, I301, D401
  Room_Type: 'General Ward' | 'Private' | 'ICU' | 'Deluxe';
  Room_Number: string;
  Availability: 'Available' | 'Occupied';
  Floor: number;
}

export interface MedicalRecord {
  Record_ID: number;
  Patient_ID: number;
  Diagnosis: string;
  Treatment: string;
  Admission_Date: string; // YYYY-MM-DD
  Discharge_Date: string; // YYYY-MM-DD
}

export interface Prescription {
  Prescription_ID: number;
  Patient_ID: number;
  Doctor_ID: number;
  Medicine_Name: string;
  Dosage: string;
}

export interface LaboratoryTest {
  Test_ID: number;
  Patient_ID: number;
  Test_Name: string;
  Test_Date: string; // YYYY-MM-DD
  Result: string;
}

export interface Billing {
  Bill_ID: number;
  Patient_ID: number;
  Total_Amount: number;
  Bill_Date: string; // YYYY-MM-DD
  Payment_Status: 'Paid' | 'Pending';
}

// Joined types for relational views
export interface JoinedAppointment extends Appointment {
  patient?: Patient;
  doctor?: Doctor;
}

export interface JoinedPrescription extends Prescription {
  patient?: Patient;
  doctor?: Doctor;
}

export interface JoinedMedicalRecord extends MedicalRecord {
  patient?: Patient;
}

export interface JoinedLaboratoryTest extends LaboratoryTest {
  patient?: Patient;
}

export interface JoinedBilling extends Billing {
  patient?: Patient;
}

export interface CompletePatientProfile {
  patient: Patient;
  appointments: JoinedAppointment[];
  medicalRecords: MedicalRecord[];
  prescriptions: JoinedPrescription[];
  laboratoryTests: LaboratoryTest[];
  bills: Billing[];
  summary: {
    totalAppointments: number;
    totalRecords: number;
    totalPrescriptions: number;
    totalLabs: number;
    totalBilled: number;
    totalPaid: number;
    totalPending: number;
    latestRecord?: MedicalRecord;
    latestLab?: LaboratoryTest;
    latestBill?: Billing;
    upcomingAppointment?: JoinedAppointment;
  };
}
