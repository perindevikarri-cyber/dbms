/**
 * CAREVAULT Laboratory Test Service
 */

import { LaboratoryTest, JoinedLaboratoryTest } from '../types/database';
import { storage } from './storage';

export const laboratoryService = {
  getAll(): LaboratoryTest[] {
    return storage.getLaboratoryTests();
  },

  getAllJoined(): JoinedLaboratoryTest[] {
    const list = storage.getLaboratoryTests();
    const patientsMap = new Map(storage.getPatients().map((p) => [p.Patient_ID, p]));

    return list
      .map((l) => ({
        ...l,
        patient: patientsMap.get(l.Patient_ID),
      }))
      .sort((a, b) => new Date(b.Test_Date).getTime() - new Date(a.Test_Date).getTime());
  },

  getById(id: number): LaboratoryTest | undefined {
    return storage.getLaboratoryTests().find((l) => l.Test_ID === id);
  },

  getByPatientId(patientId: number): LaboratoryTest[] {
    return storage.getLaboratoryTests().filter((l) => l.Patient_ID === patientId);
  },

  create(data: Omit<LaboratoryTest, 'Test_ID'>): LaboratoryTest {
    const list = storage.getLaboratoryTests();
    const maxId = list.reduce((max, item) => (item.Test_ID > max ? item.Test_ID : max), 0);
    const newTest: LaboratoryTest = {
      ...data,
      Test_ID: maxId + 1,
    };
    list.push(newTest);
    storage.setLaboratoryTests(list);
    return newTest;
  },

  update(updated: LaboratoryTest): LaboratoryTest {
    const list = storage.getLaboratoryTests();
    const index = list.findIndex((l) => l.Test_ID === updated.Test_ID);
    if (index !== -1) {
      list[index] = { ...updated };
      storage.setLaboratoryTests(list);
    }
    return updated;
  },
};
