/**
 * CAREVAULT Appointment Service
 */

import { Appointment, JoinedAppointment } from '../types/database';
import { storage } from './storage';

export const appointmentService = {
  getAll(): Appointment[] {
    return storage.getAppointments();
  },

  getAllJoined(): JoinedAppointment[] {
    const appointments = storage.getAppointments();
    const patientsMap = new Map(storage.getPatients().map((p) => [p.Patient_ID, p]));
    const doctorsMap = new Map(storage.getDoctors().map((d) => [d.Doctor_ID, d]));

    return appointments
      .map((a) => ({
        ...a,
        patient: patientsMap.get(a.Patient_ID),
        doctor: doctorsMap.get(a.Doctor_ID),
      }))
      .sort((a, b) => new Date(b.Appointment_Date).getTime() - new Date(a.Appointment_Date).getTime());
  },

  getById(id: number): Appointment | undefined {
    return storage.getAppointments().find((a) => a.Appointment_ID === id);
  },

  create(data: Omit<Appointment, 'Appointment_ID'>): Appointment {
    const list = storage.getAppointments();
    const maxId = list.reduce((max, item) => (item.Appointment_ID > max ? item.Appointment_ID : max), 0);
    const newAppointment: Appointment = {
      ...data,
      Appointment_ID: maxId + 1,
    };
    list.push(newAppointment);
    storage.setAppointments(list);
    return newAppointment;
  },

  updateStatus(id: number, status: Appointment['Status']): Appointment | undefined {
    const list = storage.getAppointments();
    const index = list.findIndex((a) => a.Appointment_ID === id);
    if (index !== -1) {
      list[index].Status = status;
      storage.setAppointments(list);
      return list[index];
    }
    return undefined;
  },

  update(updated: Appointment): Appointment {
    const list = storage.getAppointments();
    const index = list.findIndex((a) => a.Appointment_ID === updated.Appointment_ID);
    if (index !== -1) {
      list[index] = { ...updated };
      storage.setAppointments(list);
    }
    return updated;
  },
};
