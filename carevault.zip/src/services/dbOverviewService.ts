/**
 * CAREVAULT Database Overview & Analytics Service
 * Provides aggregate metrics and MySQL 8.0 Schema Definitions for DBMS project review
 */

import { storage } from './storage';

export const dbOverviewService = {
  getStats() {
    const patients = storage.getPatients();
    const doctors = storage.getDoctors();
    const appointments = storage.getAppointments();
    const billing = storage.getBilling();
    const rooms = storage.getRooms();
    const records = storage.getMedicalRecords();
    const prescriptions = storage.getPrescriptions();
    const labs = storage.getLaboratoryTests();

    const pendingBills = billing.filter((b) => b.Payment_Status === 'Pending');
    const totalPendingAmount = pendingBills.reduce((acc, b) => acc + b.Total_Amount, 0);
    const paidBills = billing.filter((b) => b.Payment_Status === 'Paid');
    const totalPaidRevenue = paidBills.reduce((acc, b) => acc + b.Total_Amount, 0);

    // Today's appointments (or scheduled appointments)
    const scheduledAppointments = appointments.filter((a) => a.Status === 'Scheduled');
    const availableRooms = rooms.filter((r) => r.Availability === 'Available').length;

    return {
      totalPatients: patients.length,
      totalDoctors: doctors.length,
      totalAppointments: appointments.length,
      scheduledAppointmentsCount: scheduledAppointments.length,
      pendingBillsCount: pendingBills.length,
      pendingBillsAmount: totalPendingAmount,
      paidRevenueAmount: totalPaidRevenue,
      totalRecords: records.length,
      totalPrescriptions: prescriptions.length,
      totalLabs: labs.length,
      totalRooms: rooms.length,
      availableRooms,
      occupiedRooms: rooms.length - availableRooms,
    };
  },

  getSchemaDetails() {
    return [
      {
        tableName: 'Patient',
        primaryKey: 'Patient_ID',
        foreignKeys: [],
        columns: [
          { name: 'Patient_ID', type: 'INT AUTO_INCREMENT', key: 'PRIMARY KEY' },
          { name: 'Name', type: 'VARCHAR(100)', key: 'NOT NULL' },
          { name: 'Age', type: 'INT', key: 'NOT NULL' },
          { name: 'Gender', type: "ENUM('Male', 'Female', 'Other')", key: 'NOT NULL' },
          { name: 'Phone_Number', type: 'VARCHAR(15)', key: 'NOT NULL' },
          { name: 'Address', type: 'VARCHAR(255)', key: 'NOT NULL' },
          { name: 'Blood_Group', type: 'VARCHAR(5)', key: 'NOT NULL' },
        ],
        ddl: `CREATE TABLE Patient (
  Patient_ID INT AUTO_INCREMENT PRIMARY KEY,
  Name VARCHAR(100) NOT NULL,
  Age INT NOT NULL,
  Gender ENUM('Male', 'Female', 'Other') NOT NULL,
  Phone_Number VARCHAR(15) NOT NULL,
  Address VARCHAR(255) NOT NULL,
  Blood_Group VARCHAR(5) NOT NULL
);`,
      },
      {
        tableName: 'Doctor',
        primaryKey: 'Doctor_ID',
        foreignKeys: [],
        columns: [
          { name: 'Doctor_ID', type: 'INT AUTO_INCREMENT', key: 'PRIMARY KEY' },
          { name: 'Name', type: 'VARCHAR(100)', key: 'NOT NULL' },
          { name: 'Department', type: 'VARCHAR(100)', key: 'NOT NULL' },
          { name: 'Specialization', type: 'VARCHAR(100)', key: 'NOT NULL' },
          { name: 'Qualification', type: 'VARCHAR(100)', key: 'NOT NULL' },
          { name: 'Phone_Number', type: 'VARCHAR(15)', key: 'NOT NULL' },
        ],
        ddl: `CREATE TABLE Doctor (
  Doctor_ID INT AUTO_INCREMENT PRIMARY KEY,
  Name VARCHAR(100) NOT NULL,
  Department VARCHAR(100) NOT NULL,
  Specialization VARCHAR(100) NOT NULL,
  Qualification VARCHAR(100) NOT NULL,
  Phone_Number VARCHAR(15) NOT NULL
);`,
      },
      {
        tableName: 'Appointment',
        primaryKey: 'Appointment_ID',
        foreignKeys: ['Patient_ID -> Patient', 'Doctor_ID -> Doctor'],
        columns: [
          { name: 'Appointment_ID', type: 'INT AUTO_INCREMENT', key: 'PRIMARY KEY' },
          { name: 'Patient_ID', type: 'INT', key: 'FOREIGN KEY REFERENCES Patient(Patient_ID)' },
          { name: 'Doctor_ID', type: 'INT', key: 'FOREIGN KEY REFERENCES Doctor(Doctor_ID)' },
          { name: 'Appointment_Date', type: 'DATE', key: 'NOT NULL' },
          { name: 'Appointment_Time', type: 'VARCHAR(20)', key: 'NOT NULL' },
          { name: 'Status', type: "ENUM('Scheduled', 'Completed', 'Cancelled')", key: "DEFAULT 'Scheduled'" },
        ],
        ddl: `CREATE TABLE Appointment (
  Appointment_ID INT AUTO_INCREMENT PRIMARY KEY,
  Patient_ID INT NOT NULL,
  Doctor_ID INT NOT NULL,
  Appointment_Date DATE NOT NULL,
  Appointment_Time VARCHAR(20) NOT NULL,
  Status ENUM('Scheduled', 'Completed', 'Cancelled') DEFAULT 'Scheduled',
  FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE,
  FOREIGN KEY (Doctor_ID) REFERENCES Doctor(Doctor_ID) ON DELETE RESTRICT
);`,
      },
      {
        tableName: 'Room',
        primaryKey: 'Room_ID',
        foreignKeys: [],
        columns: [
          { name: 'Room_ID', type: 'VARCHAR(10)', key: 'PRIMARY KEY' },
          { name: 'Room_Type', type: "ENUM('General Ward', 'Private', 'ICU', 'Deluxe')", key: 'NOT NULL' },
          { name: 'Room_Number', type: 'VARCHAR(20)', key: 'NOT NULL' },
          { name: 'Availability', type: "ENUM('Available', 'Occupied')", key: "DEFAULT 'Available'" },
          { name: 'Floor', type: 'INT', key: 'NOT NULL' },
        ],
        ddl: `CREATE TABLE Room (
  Room_ID VARCHAR(10) PRIMARY KEY,
  Room_Type ENUM('General Ward', 'Private', 'ICU', 'Deluxe') NOT NULL,
  Room_Number VARCHAR(20) NOT NULL,
  Availability ENUM('Available', 'Occupied') DEFAULT 'Available',
  Floor INT NOT NULL
);`,
      },
      {
        tableName: 'Medical_Record',
        primaryKey: 'Record_ID',
        foreignKeys: ['Patient_ID -> Patient'],
        columns: [
          { name: 'Record_ID', type: 'INT AUTO_INCREMENT', key: 'PRIMARY KEY' },
          { name: 'Patient_ID', type: 'INT', key: 'FOREIGN KEY REFERENCES Patient(Patient_ID)' },
          { name: 'Diagnosis', type: 'TEXT', key: 'NOT NULL' },
          { name: 'Treatment', type: 'TEXT', key: 'NOT NULL' },
          { name: 'Admission_Date', type: 'DATE', key: 'NOT NULL' },
          { name: 'Discharge_Date', type: 'DATE', key: 'NOT NULL' },
        ],
        ddl: `CREATE TABLE Medical_Record (
  Record_ID INT AUTO_INCREMENT PRIMARY KEY,
  Patient_ID INT NOT NULL,
  Diagnosis TEXT NOT NULL,
  Treatment TEXT NOT NULL,
  Admission_Date DATE NOT NULL,
  Discharge_Date DATE NOT NULL,
  FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE
);`,
      },
      {
        tableName: 'Prescription',
        primaryKey: 'Prescription_ID',
        foreignKeys: ['Patient_ID -> Patient', 'Doctor_ID -> Doctor'],
        columns: [
          { name: 'Prescription_ID', type: 'INT AUTO_INCREMENT', key: 'PRIMARY KEY' },
          { name: 'Patient_ID', type: 'INT', key: 'FOREIGN KEY REFERENCES Patient(Patient_ID)' },
          { name: 'Doctor_ID', type: 'INT', key: 'FOREIGN KEY REFERENCES Doctor(Doctor_ID)' },
          { name: 'Medicine_Name', type: 'VARCHAR(150)', key: 'NOT NULL' },
          { name: 'Dosage', type: 'VARCHAR(100)', key: 'NOT NULL' },
        ],
        ddl: `CREATE TABLE Prescription (
  Prescription_ID INT AUTO_INCREMENT PRIMARY KEY,
  Patient_ID INT NOT NULL,
  Doctor_ID INT NOT NULL,
  Medicine_Name VARCHAR(150) NOT NULL,
  Dosage VARCHAR(100) NOT NULL,
  FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE,
  FOREIGN KEY (Doctor_ID) REFERENCES Doctor(Doctor_ID) ON DELETE RESTRICT
);`,
      },
      {
        tableName: 'Laboratory_Test',
        primaryKey: 'Test_ID',
        foreignKeys: ['Patient_ID -> Patient'],
        columns: [
          { name: 'Test_ID', type: 'INT AUTO_INCREMENT', key: 'PRIMARY KEY' },
          { name: 'Patient_ID', type: 'INT', key: 'FOREIGN KEY REFERENCES Patient(Patient_ID)' },
          { name: 'Test_Name', type: 'VARCHAR(150)', key: 'NOT NULL' },
          { name: 'Test_Date', type: 'DATE', key: 'NOT NULL' },
          { name: 'Result', type: 'TEXT', key: 'NOT NULL' },
        ],
        ddl: `CREATE TABLE Laboratory_Test (
  Test_ID INT AUTO_INCREMENT PRIMARY KEY,
  Patient_ID INT NOT NULL,
  Test_Name VARCHAR(150) NOT NULL,
  Test_Date DATE NOT NULL,
  Result TEXT NOT NULL,
  FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE
);`,
      },
      {
        tableName: 'Billing',
        primaryKey: 'Bill_ID',
        foreignKeys: ['Patient_ID -> Patient'],
        columns: [
          { name: 'Bill_ID', type: 'INT AUTO_INCREMENT', key: 'PRIMARY KEY' },
          { name: 'Patient_ID', type: 'INT', key: 'FOREIGN KEY REFERENCES Patient(Patient_ID)' },
          { name: 'Total_Amount', type: 'DECIMAL(10,2)', key: 'NOT NULL' },
          { name: 'Bill_Date', type: 'DATE', key: 'NOT NULL' },
          { name: 'Payment_Status', type: "ENUM('Paid', 'Pending')", key: "DEFAULT 'Pending'" },
        ],
        ddl: `CREATE TABLE Billing (
  Bill_ID INT AUTO_INCREMENT PRIMARY KEY,
  Patient_ID INT NOT NULL,
  Total_Amount DECIMAL(10,2) NOT NULL,
  Bill_Date DATE NOT NULL,
  Payment_Status ENUM('Paid', 'Pending') DEFAULT 'Pending',
  FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE
);`,
      },
    ];
  },
};
