/**
 * CAREVAULT Patient Service
 * Handles CRUD operations, search, and unified record retrieval (JOIN queries emulation)
 */

import { Patient, CompletePatientProfile, JoinedAppointment, JoinedPrescription } from '../types/database';
import { storage } from './storage';

export const patientService = {
  getAll(): Patient[] {
    return storage.getPatients();
  },

  getById(id: number): Patient | undefined {
    return storage.getPatients().find((p) => p.Patient_ID === id);
  },

  search(query: string): Patient[] {
    const q = query.trim().toLowerCase();
    if (!q) return storage.getPatients();

    // Support searching "P001", "P1", "#1", or raw number "1"
    const parsedId = q.replace(/^[p#0]+/i, '');
    const numericQuery = parseInt(parsedId, 10);

    return storage.getPatients().filter((patient) => {
      const matchName = patient.Name.toLowerCase().includes(q);
      const matchAddress = patient.Address.toLowerCase().includes(q);
      const matchPhone = patient.Phone_Number.includes(q);
      const matchBlood = patient.Blood_Group.toLowerCase() === q;
      const matchId =
        patient.Patient_ID.toString() === q ||
        `p00${patient.Patient_ID}`.toLowerCase().includes(q) ||
        (!isNaN(numericQuery) && patient.Patient_ID === numericQuery);

      return matchName || matchAddress || matchPhone || matchBlood || matchId;
    });
  },

  create(patientData: Omit<Patient, 'Patient_ID'>): Patient {
    const patients = storage.getPatients();
    const maxId = patients.reduce((max, p) => (p.Patient_ID > max ? p.Patient_ID : max), 0);
    const newPatient: Patient = {
      ...patientData,
      Patient_ID: maxId + 1,
    };
    patients.push(newPatient);
    storage.setPatients(patients);
    return newPatient;
  },

  update(updated: Patient): Patient {
    const patients = storage.getPatients();
    const index = patients.findIndex((p) => p.Patient_ID === updated.Patient_ID);
    if (index !== -1) {
      patients[index] = { ...updated };
      storage.setPatients(patients);
    }
    return updated;
  },

  delete(id: number): boolean {
    const patients = storage.getPatients();
    const filtered = patients.filter((p) => p.Patient_ID !== id);
    if (filtered.length !== patients.length) {
      storage.setPatients(filtered);
      return true;
    }
    return false;
  },

  /**
   * Core DBMS Demonstration Function:
   * Retrieves full unified record for a patient by executing emulated JOIN queries
   * across Appointment, Medical_Record, Prescription, Laboratory_Test, Billing, and Doctor tables.
   */
  getCompleteProfile(patientId: number): CompletePatientProfile | null {
    const patient = this.getById(patientId);
    if (!patient) return null;

    const allDoctors = storage.getDoctors();
    const doctorsMap = new Map(allDoctors.map((d) => [d.Doctor_ID, d]));

    // 1. Appointments with JOIN Doctor
    const appointments: JoinedAppointment[] = storage
      .getAppointments()
      .filter((a) => a.Patient_ID === patientId)
      .map((a) => ({
        ...a,
        patient,
        doctor: doctorsMap.get(a.Doctor_ID),
      }))
      .sort((a, b) => new Date(b.Appointment_Date).getTime() - new Date(a.Appointment_Date).getTime());

    // 2. Medical Records
    const medicalRecords = storage
      .getMedicalRecords()
      .filter((m) => m.Patient_ID === patientId)
      .sort((a, b) => new Date(b.Admission_Date).getTime() - new Date(a.Admission_Date).getTime());

    // 3. Prescriptions with JOIN Doctor
    const prescriptions: JoinedPrescription[] = storage
      .getPrescriptions()
      .filter((p) => p.Patient_ID === patientId)
      .map((p) => ({
        ...p,
        patient,
        doctor: doctorsMap.get(p.Doctor_ID),
      }));

    // 4. Laboratory Tests
    const laboratoryTests = storage
      .getLaboratoryTests()
      .filter((l) => l.Patient_ID === patientId)
      .sort((a, b) => new Date(b.Test_Date).getTime() - new Date(a.Test_Date).getTime());

    // 5. Billing Records
    const bills = storage
      .getBilling()
      .filter((b) => b.Patient_ID === patientId)
      .sort((a, b) => new Date(b.Bill_Date).getTime() - new Date(a.Bill_Date).getTime());

    // Calculate Financial and clinical summaries
    const totalBilled = bills.reduce((sum, b) => sum + b.Total_Amount, 0);
    const totalPaid = bills.filter((b) => b.Payment_Status === 'Paid').reduce((sum, b) => sum + b.Total_Amount, 0);
    const totalPending = bills.filter((b) => b.Payment_Status === 'Pending').reduce((sum, b) => sum + b.Total_Amount, 0);

    const upcomingAppointment = appointments.find((a) => a.Status === 'Scheduled');
    const latestRecord = medicalRecords[0];
    const latestLab = laboratoryTests[0];
    const latestBill = bills[0];

    return {
      patient,
      appointments,
      medicalRecords,
      prescriptions,
      laboratoryTests,
      bills,
      summary: {
        totalAppointments: appointments.length,
        totalRecords: medicalRecords.length,
        totalPrescriptions: prescriptions.length,
        totalLabs: laboratoryTests.length,
        totalBilled,
        totalPaid,
        totalPending,
        latestRecord,
        latestLab,
        latestBill,
        upcomingAppointment,
      },
    };
  },
};
