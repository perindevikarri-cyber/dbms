/**
 * CAREVAULT Doctor Service
 */

import { Doctor } from '../types/database';
import { storage } from './storage';

export const doctorService = {
  getAll(): Doctor[] {
    return storage.getDoctors();
  },

  getById(id: number): Doctor | undefined {
    return storage.getDoctors().find((d) => d.Doctor_ID === id);
  },

  getDepartments(): string[] {
    const doctors = storage.getDoctors();
    const depts = new Set(doctors.map((d) => d.Department));
    return Array.from(depts);
  },

  search(query: string, department?: string): Doctor[] {
    const q = query.trim().toLowerCase();
    return storage.getDoctors().filter((doctor) => {
      const matchQuery =
        !q ||
        doctor.Name.toLowerCase().includes(q) ||
        doctor.Specialization.toLowerCase().includes(q) ||
        doctor.Department.toLowerCase().includes(q) ||
        doctor.Qualification.toLowerCase().includes(q) ||
        doctor.Phone_Number.includes(q);

      const matchDept = !department || department === 'All' || doctor.Department === department;

      return matchQuery && matchDept;
    });
  },

  create(doctorData: Omit<Doctor, 'Doctor_ID'>): Doctor {
    const doctors = storage.getDoctors();
    const maxId = doctors.reduce((max, d) => (d.Doctor_ID > max ? d.Doctor_ID : max), 0);
    const newDoctor: Doctor = {
      ...doctorData,
      Doctor_ID: maxId + 1,
    };
    doctors.push(newDoctor);
    storage.setDoctors(doctors);
    return newDoctor;
  },

  update(updated: Doctor): Doctor {
    const doctors = storage.getDoctors();
    const index = doctors.findIndex((d) => d.Doctor_ID === updated.Doctor_ID);
    if (index !== -1) {
      doctors[index] = { ...updated };
      storage.setDoctors(doctors);
    }
    return updated;
  },
};
