/**
 * CAREVAULT Room Service
 */

import { Room } from '../types/database';
import { storage } from './storage';

export const roomService = {
  getAll(): Room[] {
    return storage.getRooms();
  },

  getById(id: string): Room | undefined {
    return storage.getRooms().find((r) => r.Room_ID === id);
  },

  toggleAvailability(id: string): Room | undefined {
    const list = storage.getRooms();
    const index = list.findIndex((r) => r.Room_ID === id);
    if (index !== -1) {
      list[index].Availability = list[index].Availability === 'Available' ? 'Occupied' : 'Available';
      storage.setRooms(list);
      return list[index];
    }
    return undefined;
  },

  create(room: Room): Room {
    const list = storage.getRooms();
    list.push(room);
    storage.setRooms(list);
    return room;
  },

  getStats() {
    const list = storage.getRooms();
    const total = list.length;
    const available = list.filter((r) => r.Availability === 'Available').length;
    const occupied = list.filter((r) => r.Availability === 'Occupied').length;
    return { total, available, occupied };
  },
};
