/**
 * CAREVAULT Data Storage Layer
 * Emulates the MySQL 8.0 Hospital_Management_System schema with local persistence
 */

import {
  Patient,
  Doctor,
  Appointment,
  Room,
  MedicalRecord,
  Prescription,
  LaboratoryTest,
  Billing,
} from '../types/database';

const STORAGE_KEYS = {
  PATIENTS: 'carevault_patients_v1',
  DOCTORS: 'carevault_doctors_v1',
  APPOINTMENTS: 'carevault_appointments_v1',
  ROOMS: 'carevault_rooms_v1',
  MEDICAL_RECORDS: 'carevault_records_v1',
  PRESCRIPTIONS: 'carevault_prescriptions_v1',
  LABORATORY_TESTS: 'carevault_labs_v1',
  BILLING: 'carevault_billing_v1',
  INITIALIZED: 'carevault_initialized_v1',
};

// INITIAL SEED DATA ACCORDING TO SPECIFICATIONS
export const INITIAL_PATIENTS: Patient[] = [
  { Patient_ID: 1, Name: 'Rahul Kumar', Age: 24, Gender: 'Male', Phone_Number: '9876543210', Address: 'Kakinada', Blood_Group: 'O+' },
  { Patient_ID: 2, Name: 'Priya Sharma', Age: 31, Gender: 'Female', Phone_Number: '9876543211', Address: 'Rajahmundry', Blood_Group: 'B+' },
  { Patient_ID: 3, Name: 'Arjun Reddy', Age: 45, Gender: 'Male', Phone_Number: '9876543212', Address: 'Vijayawada', Blood_Group: 'A+' },
  { Patient_ID: 4, Name: 'Sneha Rao', Age: 28, Gender: 'Female', Phone_Number: '9876543213', Address: 'Visakhapatnam', Blood_Group: 'AB+' },
  { Patient_ID: 5, Name: 'Kiran Kumar', Age: 52, Gender: 'Male', Phone_Number: '9876543214', Address: 'Hyderabad', Blood_Group: 'O-' },
  { Patient_ID: 6, Name: 'Anjali Devi', Age: 36, Gender: 'Female', Phone_Number: '9876543215', Address: 'Kakinada', Blood_Group: 'A+' },
  { Patient_ID: 7, Name: 'Vikram Singh', Age: 40, Gender: 'Male', Phone_Number: '9876543216', Address: 'Chennai', Blood_Group: 'B-' },
  { Patient_ID: 8, Name: 'Meena Rani', Age: 22, Gender: 'Female', Phone_Number: '9876543217', Address: 'Rajahmundry', Blood_Group: 'O+' },
  { Patient_ID: 9, Name: 'Ravi Teja', Age: 60, Gender: 'Male', Phone_Number: '9876543218', Address: 'Vijayawada', Blood_Group: 'AB+' },
  { Patient_ID: 10, Name: 'Lakshmi Priya', Age: 48, Gender: 'Female', Phone_Number: '9876543219', Address: 'Visakhapatnam', Blood_Group: 'B+' },
];

export const INITIAL_DOCTORS: Doctor[] = [
  { Doctor_ID: 1, Name: 'Dr. Anil Kumar', Department: 'Cardiology', Specialization: 'Cardiologist', Qualification: 'MD Cardiology', Phone_Number: '9000000001' },
  { Doctor_ID: 2, Name: 'Dr. Sneha Rao', Department: 'General Medicine', Specialization: 'Physician', Qualification: 'MBBS, MD', Phone_Number: '9000000002' },
  { Doctor_ID: 3, Name: 'Dr. Ravi Teja', Department: 'Orthopedics', Specialization: 'Orthopedic Surgeon', Qualification: 'MS Orthopedics', Phone_Number: '9000000003' },
  { Doctor_ID: 4, Name: 'Dr. Priya Reddy', Department: 'Pediatrics', Specialization: 'Pediatrician', Qualification: 'MD Pediatrics', Phone_Number: '9000000004' },
  { Doctor_ID: 5, Name: 'Dr. Karthik Sharma', Department: 'Neurology', Specialization: 'Neurologist', Qualification: 'DM Neurology', Phone_Number: '9000000005' },
];

export const INITIAL_ROOMS: Room[] = [
  { Room_ID: 'G101', Room_Type: 'General Ward', Room_Number: 'G-101', Availability: 'Available', Floor: 1 },
  { Room_ID: 'G102', Room_Type: 'General Ward', Room_Number: 'G-102', Availability: 'Occupied', Floor: 1 },
  { Room_ID: 'P201', Room_Type: 'Private', Room_Number: 'P-201', Availability: 'Available', Floor: 2 },
  { Room_ID: 'P202', Room_Type: 'Private', Room_Number: 'P-202', Availability: 'Occupied', Floor: 2 },
  { Room_ID: 'I301', Room_Type: 'ICU', Room_Number: 'I-301', Availability: 'Available', Floor: 3 },
  { Room_ID: 'I302', Room_Type: 'ICU', Room_Number: 'I-302', Availability: 'Occupied', Floor: 3 },
  { Room_ID: 'D401', Room_Type: 'Deluxe', Room_Number: 'D-401', Availability: 'Available', Floor: 4 },
  { Room_ID: 'D402', Room_Type: 'Deluxe', Room_Number: 'D-402', Availability: 'Available', Floor: 4 },
];

export const INITIAL_APPOINTMENTS: Appointment[] = [
  { Appointment_ID: 1, Patient_ID: 1, Doctor_ID: 1, Appointment_Date: '2026-09-28', Appointment_Time: '09:30 AM', Status: 'Scheduled' },
  { Appointment_ID: 2, Patient_ID: 2, Doctor_ID: 2, Appointment_Date: '2026-09-28', Appointment_Time: '10:15 AM', Status: 'Scheduled' },
  { Appointment_ID: 3, Patient_ID: 3, Doctor_ID: 3, Appointment_Date: '2026-09-28', Appointment_Time: '11:00 AM', Status: 'Completed' },
  { Appointment_ID: 4, Patient_ID: 4, Doctor_ID: 4, Appointment_Date: '2026-09-29', Appointment_Time: '02:00 PM', Status: 'Scheduled' },
  { Appointment_ID: 5, Patient_ID: 5, Doctor_ID: 5, Appointment_Date: '2026-09-29', Appointment_Time: '03:30 PM', Status: 'Scheduled' },
  { Appointment_ID: 6, Patient_ID: 6, Doctor_ID: 2, Appointment_Date: '2026-09-30', Appointment_Time: '09:00 AM', Status: 'Scheduled' },
  { Appointment_ID: 7, Patient_ID: 1, Doctor_ID: 2, Appointment_Date: '2026-09-15', Appointment_Time: '10:00 AM', Status: 'Completed' },
  { Appointment_ID: 8, Patient_ID: 7, Doctor_ID: 3, Appointment_Date: '2026-09-25', Appointment_Time: '11:30 AM', Status: 'Completed' },
  { Appointment_ID: 9, Patient_ID: 9, Doctor_ID: 1, Appointment_Date: '2026-09-26', Appointment_Time: '04:00 PM', Status: 'Cancelled' },
];

export const INITIAL_MEDICAL_RECORDS: MedicalRecord[] = [
  {
    Record_ID: 101,
    Patient_ID: 1,
    Diagnosis: 'Mild Hypertension & Acute Gastritis',
    Treatment: 'Lifestyle modification, Antacids & Beta-blockers, Dietary regulation',
    Admission_Date: '2026-09-15',
    Discharge_Date: '2026-09-17',
  },
  {
    Record_ID: 102,
    Patient_ID: 2,
    Diagnosis: 'Type 2 Diabetes Mellitus with Peripheral Neuropathy',
    Treatment: 'Oral Hypoglycemic Agents (Metformin), B-complex supplements, Diabetic diet',
    Admission_Date: '2026-08-20',
    Discharge_Date: '2026-08-22',
  },
  {
    Record_ID: 103,
    Patient_ID: 3,
    Diagnosis: 'Right Knee Osteoarthritis Grade III',
    Treatment: 'Intra-articular Hyaluronic injection, Physical therapy, NSAIDs',
    Admission_Date: '2026-09-01',
    Discharge_Date: '2026-09-03',
  },
  {
    Record_ID: 104,
    Patient_ID: 5,
    Diagnosis: 'Ischemic Stroke - Left Middle Cerebral Artery',
    Treatment: 'Thrombolytic stabilization, Antiplatelet therapy, Neuro-rehabilitation',
    Admission_Date: '2026-09-10',
    Discharge_Date: '2026-09-18',
  },
  {
    Record_ID: 105,
    Patient_ID: 7,
    Diagnosis: 'Lumbar Disc Herniation (L4-L5)',
    Treatment: 'Conservative bed rest, Lumbar traction, Muscle relaxants',
    Admission_Date: '2026-09-12',
    Discharge_Date: '2026-09-15',
  },
];

export const INITIAL_PRESCRIPTIONS: Prescription[] = [
  {
    Prescription_ID: 201,
    Patient_ID: 1,
    Doctor_ID: 1,
    Medicine_Name: 'Amlodipine',
    Dosage: '5 mg once daily',
  },
  {
    Prescription_ID: 202,
    Patient_ID: 1,
    Doctor_ID: 2,
    Medicine_Name: 'Pantoprazole',
    Dosage: '40 mg once daily (before breakfast)',
  },
  {
    Prescription_ID: 203,
    Patient_ID: 2,
    Doctor_ID: 2,
    Medicine_Name: 'Metformin Hydrochloride',
    Dosage: '500 mg twice daily with meals',
  },
  {
    Prescription_ID: 204,
    Patient_ID: 3,
    Doctor_ID: 3,
    Medicine_Name: 'Aceclofenac + Paracetamol',
    Dosage: '100mg/325mg twice daily after food',
  },
  {
    Prescription_ID: 205,
    Patient_ID: 5,
    Doctor_ID: 5,
    Medicine_Name: 'Atorvastatin + Clopidogrel',
    Dosage: '20mg/75mg once at bedtime',
  },
  {
    Prescription_ID: 206,
    Patient_ID: 6,
    Doctor_ID: 2,
    Medicine_Name: 'Amoxicillin + Clavulanic Acid',
    Dosage: '625 mg three times daily for 5 days',
  },
];

export const INITIAL_LABORATORY_TESTS: LaboratoryTest[] = [
  {
    Test_ID: 301,
    Patient_ID: 1,
    Test_Name: 'Lipid Profile & ECG',
    Test_Date: '2026-09-27',
    Result: 'Total Cholesterol 195 mg/dL (Normal <200), Normal Sinus Rhythm',
  },
  {
    Test_ID: 302,
    Patient_ID: 1,
    Test_Name: 'Complete Blood Count (CBC)',
    Test_Date: '2026-09-15',
    Result: 'Hemoglobin 14.8 g/dL, WBC 7,200 /mcL, Platelets 260,000 /mcL (Normal)',
  },
  {
    Test_ID: 303,
    Patient_ID: 2,
    Test_Name: 'HbA1c Glycated Hemoglobin',
    Test_Date: '2026-09-20',
    Result: '7.8% (Target for DM < 7.0%)',
  },
  {
    Test_ID: 304,
    Patient_ID: 3,
    Test_Name: 'X-Ray Right Knee AP & Lateral',
    Test_Date: '2026-09-01',
    Result: 'Medial joint space narrowing, subchondral sclerosis present',
  },
  {
    Test_ID: 305,
    Patient_ID: 5,
    Test_Name: 'Brain MRI with Angiography',
    Test_Date: '2026-09-10',
    Result: 'Subacute infarct in right MCA territory, no midline shift',
  },
  {
    Test_ID: 306,
    Patient_ID: 7,
    Test_Name: 'Lumbar Spine MRI',
    Test_Date: '2026-09-12',
    Result: 'Posterocentral disc extrusion at L4-L5 contacting the thecal sac',
  },
];

export const INITIAL_BILLING: Billing[] = [
  { Bill_ID: 401, Patient_ID: 1, Total_Amount: 4500, Bill_Date: '2026-09-28', Payment_Status: 'Paid' },
  { Bill_ID: 402, Patient_ID: 2, Total_Amount: 2800, Bill_Date: '2026-09-28', Payment_Status: 'Paid' },
  { Bill_ID: 403, Patient_ID: 3, Total_Amount: 6800, Bill_Date: '2026-09-26', Payment_Status: 'Pending' },
  { Bill_ID: 404, Patient_ID: 4, Total_Amount: 1200, Bill_Date: '2026-09-27', Payment_Status: 'Paid' },
  { Bill_ID: 405, Patient_ID: 5, Total_Amount: 34500, Bill_Date: '2026-09-18', Payment_Status: 'Pending' },
  { Bill_ID: 406, Patient_ID: 6, Total_Amount: 950, Bill_Date: '2026-09-25', Payment_Status: 'Paid' },
  { Bill_ID: 407, Patient_ID: 7, Total_Amount: 14200, Bill_Date: '2026-09-15', Payment_Status: 'Paid' },
  { Bill_ID: 408, Patient_ID: 9, Total_Amount: 3200, Bill_Date: '2026-09-26', Payment_Status: 'Pending' },
];

class StorageService {
  private inMemoryCache: Record<string, any> = {};

  constructor() {
    this.ensureInitialized();
  }

  public ensureInitialized(forceReset = false) {
    if (typeof window === 'undefined') return;

    const initialized = localStorage.getItem(STORAGE_KEYS.INITIALIZED);
    if (!initialized || forceReset) {
      this.set(STORAGE_KEYS.PATIENTS, INITIAL_PATIENTS);
      this.set(STORAGE_KEYS.DOCTORS, INITIAL_DOCTORS);
      this.set(STORAGE_KEYS.APPOINTMENTS, INITIAL_APPOINTMENTS);
      this.set(STORAGE_KEYS.ROOMS, INITIAL_ROOMS);
      this.set(STORAGE_KEYS.MEDICAL_RECORDS, INITIAL_MEDICAL_RECORDS);
      this.set(STORAGE_KEYS.PRESCRIPTIONS, INITIAL_PRESCRIPTIONS);
      this.set(STORAGE_KEYS.LABORATORY_TESTS, INITIAL_LABORATORY_TESTS);
      this.set(STORAGE_KEYS.BILLING, INITIAL_BILLING);
      localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
    }
  }

  public get<T>(key: string, defaultValue: T): T {
    if (typeof window === 'undefined') return defaultValue;
    try {
      const item = localStorage.getItem(key);
      if (!item) return defaultValue;
      return JSON.parse(item) as T;
    } catch {
      return defaultValue;
    }
  }

  public set<T>(key: string, value: T): void {
    if (typeof window === 'undefined') {
      this.inMemoryCache[key] = value;
      return;
    }
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Failed to write to localStorage for key: ${key}`, e);
    }
  }

  // Getters for individual tables
  public getPatients(): Patient[] {
    return this.get<Patient[]>(STORAGE_KEYS.PATIENTS, INITIAL_PATIENTS);
  }

  public setPatients(data: Patient[]): void {
    this.set(STORAGE_KEYS.PATIENTS, data);
  }

  public getDoctors(): Doctor[] {
    return this.get<Doctor[]>(STORAGE_KEYS.DOCTORS, INITIAL_DOCTORS);
  }

  public setDoctors(data: Doctor[]): void {
    this.set(STORAGE_KEYS.DOCTORS, data);
  }

  public getAppointments(): Appointment[] {
    return this.get<Appointment[]>(STORAGE_KEYS.APPOINTMENTS, INITIAL_APPOINTMENTS);
  }

  public setAppointments(data: Appointment[]): void {
    this.set(STORAGE_KEYS.APPOINTMENTS, data);
  }

  public getRooms(): Room[] {
    return this.get<Room[]>(STORAGE_KEYS.ROOMS, INITIAL_ROOMS);
  }

  public setRooms(data: Room[]): void {
    this.set(STORAGE_KEYS.ROOMS, data);
  }

  public getMedicalRecords(): MedicalRecord[] {
    return this.get<MedicalRecord[]>(STORAGE_KEYS.MEDICAL_RECORDS, INITIAL_MEDICAL_RECORDS);
  }

  public setMedicalRecords(data: MedicalRecord[]): void {
    this.set(STORAGE_KEYS.MEDICAL_RECORDS, data);
  }

  public getPrescriptions(): Prescription[] {
    return this.get<Prescription[]>(STORAGE_KEYS.PRESCRIPTIONS, INITIAL_PRESCRIPTIONS);
  }

  public setPrescriptions(data: Prescription[]): void {
    this.set(STORAGE_KEYS.PRESCRIPTIONS, data);
  }

  public getLaboratoryTests(): LaboratoryTest[] {
    return this.get<LaboratoryTest[]>(STORAGE_KEYS.LABORATORY_TESTS, INITIAL_LABORATORY_TESTS);
  }

  public setLaboratoryTests(data: LaboratoryTest[]): void {
    this.set(STORAGE_KEYS.LABORATORY_TESTS, data);
  }

  public getBilling(): Billing[] {
    return this.get<Billing[]>(STORAGE_KEYS.BILLING, INITIAL_BILLING);
  }

  public setBilling(data: Billing[]): void {
    this.set(STORAGE_KEYS.BILLING, data);
  }

  public resetToDefault(): void {
    this.ensureInitialized(true);
  }
}

export const storage = new StorageService();
