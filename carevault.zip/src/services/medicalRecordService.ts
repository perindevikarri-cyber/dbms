/**
 * CAREVAULT Medical Record Service
 */

import { MedicalRecord, JoinedMedicalRecord } from '../types/database';
import { storage } from './storage';

export const medicalRecordService = {
  getAll(): MedicalRecord[] {
    return storage.getMedicalRecords();
  },

  getAllJoined(): JoinedMedicalRecord[] {
    const records = storage.getMedicalRecords();
    const patientsMap = new Map(storage.getPatients().map((p) => [p.Patient_ID, p]));

    return records
      .map((r) => ({
        ...r,
        patient: patientsMap.get(r.Patient_ID),
      }))
      .sort((a, b) => new Date(b.Admission_Date).getTime() - new Date(a.Admission_Date).getTime());
  },

  getById(id: number): MedicalRecord | undefined {
    return storage.getMedicalRecords().find((r) => r.Record_ID === id);
  },

  getByPatientId(patientId: number): MedicalRecord[] {
    return storage.getMedicalRecords().filter((r) => r.Patient_ID === patientId);
  },

  create(data: Omit<MedicalRecord, 'Record_ID'>): MedicalRecord {
    const list = storage.getMedicalRecords();
    const maxId = list.reduce((max, item) => (item.Record_ID > max ? item.Record_ID : max), 0);
    const newRecord: MedicalRecord = {
      ...data,
      Record_ID: maxId + 1,
    };
    list.push(newRecord);
    storage.setMedicalRecords(list);
    return newRecord;
  },

  update(updated: MedicalRecord): MedicalRecord {
    const list = storage.getMedicalRecords();
    const index = list.findIndex((r) => r.Record_ID === updated.Record_ID);
    if (index !== -1) {
      list[index] = { ...updated };
      storage.setMedicalRecords(list);
    }
    return updated;
  },
};
