/**
 * CAREVAULT Billing Service
 */

import { Billing, JoinedBilling } from '../types/database';
import { storage } from './storage';

export const billingService = {
  getAll(): Billing[] {
    return storage.getBilling();
  },

  getAllJoined(): JoinedBilling[] {
    const list = storage.getBilling();
    const patientsMap = new Map(storage.getPatients().map((p) => [p.Patient_ID, p]));

    return list
      .map((b) => ({
        ...b,
        patient: patientsMap.get(b.Patient_ID),
      }))
      .sort((a, b) => new Date(b.Bill_Date).getTime() - new Date(a.Bill_Date).getTime());
  },

  getById(id: number): Billing | undefined {
    return storage.getBilling().find((b) => b.Bill_ID === id);
  },

  getByPatientId(patientId: number): Billing[] {
    return storage.getBilling().filter((b) => b.Patient_ID === patientId);
  },

  create(data: Omit<Billing, 'Bill_ID'>): Billing {
    const list = storage.getBilling();
    const maxId = list.reduce((max, item) => (item.Bill_ID > max ? item.Bill_ID : max), 0);
    const newBill: Billing = {
      ...data,
      Bill_ID: maxId + 1,
    };
    list.push(newBill);
    storage.setBilling(list);
    return newBill;
  },

  updateStatus(id: number, status: 'Paid' | 'Pending'): Billing | undefined {
    const list = storage.getBilling();
    const index = list.findIndex((b) => b.Bill_ID === id);
    if (index !== -1) {
      list[index].Payment_Status = status;
      storage.setBilling(list);
      return list[index];
    }
    return undefined;
  },

  getSummary() {
    const list = storage.getBilling();
    const totalBilled = list.reduce((acc, b) => acc + b.Total_Amount, 0);
    const totalPaid = list.filter((b) => b.Payment_Status === 'Paid').reduce((acc, b) => acc + b.Total_Amount, 0);
    const totalPending = list.filter((b) => b.Payment_Status === 'Pending').reduce((acc, b) => acc + b.Total_Amount, 0);
    const pendingCount = list.filter((b) => b.Payment_Status === 'Pending').length;
    const paidCount = list.filter((b) => b.Payment_Status === 'Paid').length;

    return {
      totalBilled,
      totalPaid,
      totalPending,
      pendingCount,
      paidCount,
      totalCount: list.length,
    };
  },
};
