/**
 * CAREVAULT Prescription Service
 */

import { Prescription, JoinedPrescription } from '../types/database';
import { storage } from './storage';

export const prescriptionService = {
  getAll(): Prescription[] {
    return storage.getPrescriptions();
  },

  getAllJoined(): JoinedPrescription[] {
    const list = storage.getPrescriptions();
    const patientsMap = new Map(storage.getPatients().map((p) => [p.Patient_ID, p]));
    const doctorsMap = new Map(storage.getDoctors().map((d) => [d.Doctor_ID, d]));

    return list.map((p) => ({
      ...p,
      patient: patientsMap.get(p.Patient_ID),
      doctor: doctorsMap.get(p.Doctor_ID),
    }));
  },

  getById(id: number): Prescription | undefined {
    return storage.getPrescriptions().find((p) => p.Prescription_ID === id);
  },

  getByPatientId(patientId: number): Prescription[] {
    return storage.getPrescriptions().filter((p) => p.Patient_ID === patientId);
  },

  create(data: Omit<Prescription, 'Prescription_ID'>): Prescription {
    const list = storage.getPrescriptions();
    const maxId = list.reduce((max, item) => (item.Prescription_ID > max ? item.Prescription_ID : max), 0);
    const newPrescription: Prescription = {
      ...data,
      Prescription_ID: maxId + 1,
    };
    list.push(newPrescription);
    storage.setPrescriptions(list);
    return newPrescription;
  },

  update(updated: Prescription): Prescription {
    const list = storage.getPrescriptions();
    const index = list.findIndex((p) => p.Prescription_ID === updated.Prescription_ID);
    if (index !== -1) {
      list[index] = { ...updated };
      storage.setPrescriptions(list);
    }
    return updated;
  },
};
